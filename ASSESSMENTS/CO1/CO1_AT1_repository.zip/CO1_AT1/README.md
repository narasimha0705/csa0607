# CO1_AT1 – CSA06 Design and Analysis of Algorithms

**Assessment:** CO1 – Assessment Tool 1: Scalability Audit of an E-Commerce Platform ("ShopSphere")
**Student:** <Name> | **Reg. No.:** <Reg. No.>

## Structure
```
CO1_AT1/
├── README.md
└── Question_1/
    ├── Source_Code/   Python programs for every part (a)–(g)
    └── Report/        CSA06_CO1_Report.docx, screenshots/, outputs/
```

## Source files
| File | Covers |
|---|---|
| `m1_duplicate_detector.py` | M1 – exact count n(n−1)/2, Θ(n²), O(1) space |
| `m2_rate_limiter.py` | M2 – 2^⌈log₂n⌉−1 audits, Θ(n); n = 1,024 → 1023 |
| `m3_search.py` | M3 – S1/S2, T(n)=T(n/2)+1 = log₂n+1, best/avg/worst, S1 average |
| `m4_m5_recurrences.py` | M4, M5 – Master Theorem, closed forms, doubling ratios |
| `f_asymptotic_proof.py` | Part (f) – 3n² ≤ f(n) ≤ 63n², f ∉ O(n) |
| `g_scalability.py` | Part (g) – operations/time at n = 10⁵ and 10⁶ |
| `plot_growth.py` | Growth chart (needs matplotlib) |
| `run_all.py` | Runs everything and stores output in `Report/outputs/` |

## Run
```bash
cd Question_1/Source_Code
python run_all.py
```
Python 3.8+; no external libraries except matplotlib for `plot_growth.py`.

## Key results (n = 1,000,000, 10⁸ ops/s, 10-min window)
| Module | Complexity | Time | Verdict |
|---|---|---|---|
| M1 | Θ(n²) | 83.3 min | FAIL → redesign (hash set / sort) |
| M2 | Θ(n) | 10.5 ms | PASS |
| S2 | Θ(log n) | 0.2 µs | PASS |
| M4 current | Θ(n²) | 5.56 h | FAIL → redesign |
| M4 redesign | Θ(n log n) | 0.21 s | PASS |
| M5 | Θ(n log² n) | 2.1 s | PASS |
