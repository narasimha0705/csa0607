"""Module M1 - Duplicate-Listing Detector (nested loops, Theta(n^2))."""
import time


def detect_duplicates(products):
    """Pseudocode from the question. Returns (duplicate_indices, comparisons)."""
    n = len(products)
    dup, comparisons = set(), 0
    for i in range(0, n - 1):                # FOR i <- 0 TO n-2
        for j in range(i + 1, n):            # FOR j <- i+1 TO n-1
            comparisons += 1                 # basic operation: title/seller test
            if (products[i][0] == products[j][0]
                    and products[i][1] == products[j][1]):
                dup.add(j)                   # MarkDuplicate(j)
    return dup, comparisons


def count_only(n):
    """Count the basic operation without comparing data (for large n)."""
    c = 0
    for i in range(0, n - 1):
        c += (n - 1) - (i + 1) + 1
    return c


if __name__ == "__main__":
    print("== M1: functional test ==")
    sample = [("Phone", "A"), ("Laptop", "B"), ("Phone", "A"),
              ("Phone", "C"), ("Laptop", "B")]
    d, c = detect_duplicates(sample)
    print(f"products={len(sample)} duplicates at index {sorted(d)}, comparisons={c}")

    print("\n== M1: exact count vs formula n(n-1)/2 ==")
    print(f"{'n':>8} {'counted':>14} {'n(n-1)/2':>14} {'match':>6}")
    for n in (2, 5, 10, 100, 1000, 5000):
        cnt = count_only(n)
        f = n * (n - 1) // 2
        print(f"{n:>8} {cnt:>14} {f:>14} {str(cnt == f):>6}")

    print("\n== M1: running-time growth (doubling n should ~4x time) ==")
    prev = None
    for n in (1000, 2000, 4000):
        data = [(f"t{k}", f"s{k % 7}") for k in range(n)]
        t0 = time.perf_counter()
        detect_duplicates(data)
        t = time.perf_counter() - t0
        ratio = f"{t / prev:.2f}x" if prev else "-"
        print(f"n={n:>5}  time={t:.4f}s  ratio={ratio}")
        prev = t
    print("\nSpace: only i, j, counter -> O(1) auxiliary (input itself is O(n)).")
