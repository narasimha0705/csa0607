"""Numerical check of the proof f(n)=3n^2+10 n log2 n+50 = Theta(n^2), not O(n)."""
import math


def f(n):
    return 3 * n * n + 10 * n * math.log2(n) + 50 if n > 1 else 53


if __name__ == "__main__":
    c1, c2, n0 = 3, 63, 1
    ok = all(c1 * n * n <= f(n) <= c2 * n * n for n in range(n0, 200001))
    print(f"Bound  {c1}n^2 <= f(n) <= {c2}n^2 for 1<=n<=200000 : {ok}")
    c2b, n0b = 4, 64
    ok2 = all(c1 * n * n <= f(n) <= c2b * n * n for n in range(n0b, 200001))
    print(f"Tighter {c1}n^2 <= f(n) <= {c2b}n^2 for 64<=n<=200000: {ok2}"
          f"   (n=63 fails: {f(63) > c2b * 63 * 63})")
    print("\n== f(n)/n grows without bound  =>  f(n) is not O(n) ==")
    for n in (10, 100, 10_000, 1_000_000):
        print(f"n={n:>9}  f(n)/n = {f(n) / n:>14,.1f}   f(n)/n^2 = {f(n) / n ** 2:.4f}")
