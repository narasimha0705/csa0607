"""Modules M4 and M5 - Master Theorem and recursion-tree analysis."""
import math
from functools import lru_cache


@lru_cache(None)
def T4_current(n):
    return 1 if n == 1 else 4 * T4_current(n // 2) + n


@lru_cache(None)
def T4_redesign(n):
    return 1 if n == 1 else 2 * T4_redesign(n // 2) + n


@lru_cache(None)
def T5(n):
    return 1 if n == 1 else 2 * T5(n // 2) + n * math.log2(n)


def master(a, b, d, k=0):
    """T(n)=aT(n/b)+Theta(n^d log^k n). Returns the case and the bound."""
    crit = math.log(a, b)
    nn = lambda e: "n" if e == 1 else f"n^{e:g}"
    lg = lambda e: "" if e == 0 else (" log n" if e == 1 else f" log^{e} n")
    if d < crit - 1e-12:
        return "Case 1", f"Theta({nn(crit)})"
    if abs(d - crit) < 1e-12:
        return ("Case 2" if k == 0 else "Case 2 (extended, k=%d)" % k), \
            f"Theta({nn(d)}{lg(k + 1)})"
    return "Case 3", f"Theta({nn(d)}{lg(k)})"


if __name__ == "__main__":
    print("== Master Theorem ==")
    for name, (a, b, d, k) in {"M4 current  T=4T(n/2)+n": (4, 2, 1, 0),
                               "M4 redesign T=2T(n/2)+n": (2, 2, 1, 0),
                               "M5          T=2T(n/2)+n log n": (2, 2, 1, 1)}.items():
        case, bound = master(a, b, d, k)
        print(f"{name:<32} a={a} b={b} n^log_b(a)=n^{math.log(a, b):g}  "
              f"-> {case}: {bound}")

    print("\n== Recurrence values vs closed forms (n = 2^k) ==")
    print(f"{'k':>3} {'n':>9} {'T4cur':>14} {'2n^2-n':>14} {'T4new':>12} "
          f"{'n log n+n':>12} {'T5':>14} {'n+n k(k+1)/2':>14}")
    for k in (1, 4, 8, 12, 16):
        n = 2 ** k
        print(f"{k:>3} {n:>9} {T4_current(n):>14} {2 * n * n - n:>14} "
              f"{T4_redesign(n):>12} {n * k + n:>12} {T5(n):>14.0f} "
              f"{n + n * k * (k + 1) / 2:>14.0f}")

    print("\n== Doubling the data: T(2n)/T(n) ==")
    for n in (2 ** 10, 2 ** 14, 2 ** 18):
        print(f"n=2^{int(math.log2(n)):<2} current x{T4_current(2 * n) / T4_current(n):.3f}"
              f"   redesign x{T4_redesign(2 * n) / T4_redesign(n):.3f}"
              f"   M5 x{T5(2 * n) / T5(n):.3f}")
