"""Runs every module and saves each output under ../Report/outputs/."""
import subprocess, sys, os

FILES = ["m1_duplicate_detector", "m2_rate_limiter", "m3_search",
         "m4_m5_recurrences", "f_asymptotic_proof", "g_scalability"]
os.makedirs("../Report/outputs", exist_ok=True)
for f in FILES:
    out = subprocess.run([sys.executable, f + ".py"], capture_output=True, text=True).stdout
    open(f"../Report/outputs/{f}.txt", "w").write(out)
    print(out)
