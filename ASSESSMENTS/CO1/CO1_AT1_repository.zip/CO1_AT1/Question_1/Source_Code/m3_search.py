"""Module M3 - Product Search: S1 sequential vs S2 binary (iterative + recursive)."""
import math


def s1_sequential(a, key):
    comps = 0
    for x in a:
        comps += 1
        if x == key:
            return True, comps
    return False, comps


def s2_binary_iter(a, key):
    lo, hi, comps = 0, len(a) - 1, 0
    while lo <= hi:
        mid = (lo + hi) // 2
        comps += 1                    # one comparison per halving step
        if a[mid] == key:
            return True, comps
        if a[mid] < key:
            lo = mid + 1
        else:
            hi = mid - 1
    return False, comps


def s2_binary_rec(a, key, lo, hi, depth=1):
    """Returns (found, comparisons, max recursion depth reached)."""
    if lo > hi:
        return False, 0, depth - 1
    mid = (lo + hi) // 2
    if a[mid] == key:
        return True, 1, depth
    if a[mid] < key:
        f, c, d = s2_binary_rec(a, key, mid + 1, hi, depth + 1)
    else:
        f, c, d = s2_binary_rec(a, key, lo, mid - 1, depth + 1)
    return f, c + 1, d


def T(n):
    """Recurrence T(n)=T(n/2)+1, T(1)=1 (n a power of 2)."""
    return 1 if n == 1 else T(n // 2) + 1


def s1_average(n, p):
    """p*(n+1)/2 + (1-p)*n."""
    return p * (n + 1) / 2 + (1 - p) * n


if __name__ == "__main__":
    print("== Recurrence T(n)=T(n/2)+1 vs closed form log2(n)+1 ==")
    for k in range(0, 21, 4):
        n = 2 ** k
        print(f"n=2^{k:<2} = {n:>8}  T(n)={T(n):>3}  log2(n)+1={k + 1:>3}")

    n = 1 << 16
    a = list(range(n))
    print("\n== Best / worst / average (n = 2^16 = 65,536, exhaustive) ==")
    print("S1 best  (first item)   :", s1_sequential(a, 0)[1])
    print("S1 worst (last item)    :", s1_sequential(a, n - 1)[1])
    print("S1 worst (absent)       :", s1_sequential(a, -1)[1])
    runs = [s2_binary_iter(a, x)[1] for x in a]
    print("S2 best  (middle item)  :", min(runs))
    print("S2 worst (deepest item) :", max(runs), "= log2(n)+1 =", 17)
    print(f"S2 average (all {n} hits): {sum(runs) / n:.3f}  (~log2 n - 1 = 15)")
    m = 1000
    b = list(range(m))
    succ = sum(s1_sequential(b, x)[1] for x in b) / m
    print(f"\nS1 average, successful, n={m}: {succ} = (n+1)/2 = {(m + 1) / 2}")

    print("\n== S1 average with probability p of presence ==")
    for p in (1.0, 0.5, 0.0):
        print(f"n=1,000,000  p={p}:  A(n)={s1_average(1_000_000, p):,.2f}")

    print("\n== Space: iterative vs recursive binary search (n = 1,000,000) ==")
    big = list(range(1_000_000))
    f, c, d = s2_binary_rec(big, -1, 0, len(big) - 1)
    print(f"recursive depth reached = {d} (~log2 n = {math.log2(1_000_000):.1f})")
    print("iterative: lo, hi, mid only -> O(1) space; recursive: O(log n) stack")
