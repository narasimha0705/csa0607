"""Scalability decision: operation counts and running time at n = 100,000 and 1,000,000."""
import math

SPEED = 1e8           # basic operations per second
WINDOW = 600          # 10-minute nightly window (seconds)


def lg(n):
    return math.log2(n)


MODULES = {
    "M1  n(n-1)/2":              lambda n: n * (n - 1) / 2,
    "M2  2^ceil(lg n)-1":        lambda n: 2 ** math.ceil(lg(n)) - 1,
    "S2  floor(lg n)+1":         lambda n: math.floor(lg(n)) + 1,
    "M4 current  ~2n^2-n":       lambda n: 2 * n * n - n,
    "M4 redesign ~n lg n + n":   lambda n: n * lg(n) + n,
    "M5  ~n+n k(k+1)/2":         lambda n: n + n * lg(n) * (lg(n) + 1) / 2,
}


def human(t):
    if t < 1e-3:
        return f"{t * 1e6:.2f} us"
    if t < 1:
        return f"{t * 1e3:.2f} ms"
    if t < 600:
        return f"{t:.2f} s"
    if t < 7200:
        return f"{t / 60:.1f} min"
    return f"{t / 3600:.2f} h"


if __name__ == "__main__":
    for n in (100_000, 1_000_000):
        print(f"\n=== n = {n:,} (speed 1e8 ops/s, window 10 min = {WINDOW}s) ===")
        print(f"{'module':<26}{'operations':>18}{'time':>14}   verdict")
        for name, fn in MODULES.items():
            ops = fn(n)
            t = ops / SPEED
            print(f"{name:<26}{ops:>18,.0f}{human(t):>14}   "
                  f"{'PASS' if t <= WINDOW else 'FAIL'}")
    print("\nM1 speed-up if replaced by hashing: n ops =",
          f"{1_000_000:,} -> {human(1_000_000 / SPEED)}")
