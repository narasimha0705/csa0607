"""Draws growth-rate chart used in the report (needs matplotlib)."""
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ns = [2 ** k for k in range(4, 21)]
plt.figure(figsize=(8, 5))
plt.loglog(ns, [n * (n - 1) / 2 for n in ns], "o-", label="M1  Theta(n^2)")
plt.loglog(ns, [2 * n * n - n for n in ns], "s-", label="M4 current  Theta(n^2)")
plt.loglog(ns, [n + n * math.log2(n) * (math.log2(n) + 1) / 2 for n in ns], "^-", label="M5  Theta(n log^2 n)")
plt.loglog(ns, [n * math.log2(n) + n for n in ns], "d-", label="M4 redesign  Theta(n log n)")
plt.loglog(ns, [2 ** math.ceil(math.log2(n)) - 1 for n in ns], "x-", label="M2  Theta(n)")
plt.loglog(ns, [math.log2(n) + 1 for n in ns], "v-", label="S2  Theta(log n)")
plt.axhline(6e10, color="red", ls="--", label="10-min window (6e10 ops)")
plt.xlabel("n (products)"); plt.ylabel("basic operations")
plt.title("ShopSphere - growth of basic operations"); plt.grid(True, which="both", alpha=.3)
plt.legend(fontsize=8); plt.tight_layout()
plt.savefig("../Report/screenshots/growth_chart.png", dpi=150)
print("saved ../Report/screenshots/growth_chart.png")
