"""Module M2 - API Rate Limiter (doubling window): Theta(n), NOT Theta(n log n)."""
import math


def audit_count(n):
    """Count Audit() calls of the question's routine."""
    i, ops = 1, 0
    while i < n:                  # WHILE i < n
        for _ in range(i):        # FOR j <- 0 TO i-1  -> i calls of Audit
            ops += 1
        i *= 2                    # i <- i * 2
    return ops


def closed_form(n):
    """Sum_{k=0}^{ceil(log2 n)-1} 2^k = 2^ceil(log2 n) - 1."""
    return 2 ** math.ceil(math.log2(n)) - 1


if __name__ == "__main__":
    print("== M2: counted vs closed form 2^ceil(log2 n) - 1 ==")
    print(f"{'n':>10} {'counted':>10} {'formula':>10} {'n log2 n':>12} "
          f"{'counted/n':>10} {'match':>6}")
    for n in (2, 8, 100, 1000, 1024, 5000, 100000, 1000000):
        c, f = audit_count(n), closed_form(n)
        print(f"{n:>10} {c:>10} {f:>10} {n * math.log2(n):>12.0f} "
              f"{c / n:>10.3f} {str(c == f):>6}")

    print("\n== Verification for n = 1024 ==")
    i, parts = 1, []
    while i < 1024:
        parts.append(i)
        i *= 2
    print("window sizes :", parts)
    print("sum          :", sum(parts), "(= 2^10 - 1 = 1023)")
    print("team claim n*log2 n =", 1024 * 10, "-> about 10x too large")
    print("counted/n bounded between 1 and 2  =>  Theta(n)")
