"""
Module 2 - Live Seller Leaderboard (Quick Sort)
Compares first-element pivot with median-of-three pivot. Iterative (explicit stack) so deep
worst-case recursion does not crash. Sorts in ascending order.
"""
import math
import random

comparisons = 0


def partition_first(a, lo, hi, trace=None):
    """Lomuto-style partition using the FIRST element as pivot."""
    global comparisons
    pivot = a[lo]
    i = lo
    if trace is not None:
        trace.append(f"pivot = a[{lo}] = {pivot}; array = {a[lo:hi + 1]}")
    for j in range(lo + 1, hi + 1):
        comparisons += 1
        value = a[j]
        if value < pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
            if trace is not None:
                trace.append(f"  j={j}: {value} < {pivot} -> i={i}, swap a[{i}] and a[{j}] -> {a[lo:hi + 1]}")
        elif trace is not None:
            trace.append(f"  j={j}: {value} >= {pivot} -> no swap (i={i})")
    a[lo], a[i] = a[i], a[lo]
    if trace is not None:
        trace.append(f"  place pivot: swap a[{lo}] and a[{i}] -> {a[lo:hi + 1]}")
    return i


def partition_hoare(a, lo, hi):
    """Hoare partition around the value at the middle position. Keeps sorted runs intact,
    which is why it pairs well with median-of-three on nearly sorted data. Returns split index j."""
    global comparisons
    pivot = a[(lo + hi) // 2]
    i, j = lo - 1, hi + 1
    while True:
        i += 1
        comparisons += 1
        while a[i] < pivot:
            i += 1
            comparisons += 1
        j -= 1
        comparisons += 1
        while a[j] > pivot:
            j -= 1
            comparisons += 1
        if i >= j:
            return j
        a[i], a[j] = a[j], a[i]


def median_of_three(a, lo, hi):
    """Order a[lo], a[mid], a[hi] in place so that a[mid] holds their median."""
    global comparisons
    mid = (lo + hi) // 2
    for x, y in ((lo, mid), (mid, hi), (lo, mid)):
        comparisons += 1
        if a[x] > a[y]:
            a[x], a[y] = a[y], a[x]


def quick_sort(a, strategy="first"):
    """strategy: 'first' | 'median3' | 'random'. Returns the number of comparisons."""
    global comparisons
    comparisons = 0
    stack = [(0, len(a) - 1)]
    while stack:
        lo, hi = stack.pop()
        if lo >= hi:
            continue
        if strategy == "first":                 # current production behaviour
            p = partition_first(a, lo, hi)
            parts = [(lo, p - 1), (p + 1, hi)]
        else:
            if strategy == "median3":
                median_of_three(a, lo, hi)
            else:                               # random pivot moved to the middle position
                m = random.randint(lo, hi)
                mid = (lo + hi) // 2
                a[m], a[mid] = a[mid], a[m]
            p = partition_hoare(a, lo, hi)
            parts = [(lo, p), (p + 1, hi)]
        # push the larger part first so the smaller one is processed first (stack stays O(log n))
        parts.sort(key=lambda r: r[1] - r[0])
        stack.append(parts[1])
        stack.append(parts[0])
    return comparisons


def nearly_sorted(n, swaps, seed=1):
    random.seed(seed)
    a = list(range(n))
    for _ in range(swaps):
        i, j = random.randrange(n), random.randrange(n)
        a[i], a[j] = a[j], a[i]
    return a


if __name__ == "__main__":
    scores = [42, 17, 63, 8, 55, 29]
    print("SAMPLE SCORES:", scores)
    trace = []
    arr = scores[:]
    p = partition_first(arr, 0, len(arr) - 1, trace)
    print("\nONE PARTITION STEP (first-element pivot)")
    print("\n".join(trace))
    print(f"Pivot 42 is now at index {p}; left {arr[:p]} < 42 <= right {arr[p + 1:]}")

    full = scores[:]
    quick_sort(full, "first")
    print("\nFULL SORT:", full)

    print("\nEXPERIMENT: nearly sorted data (10 random swaps)")
    print(f"{'n':>8} {'first-pivot':>14} {'n(n-1)/2':>14} {'median-of-3':>13} {'random':>10} {'n lg n':>10}")
    rows = []
    for n in (250, 500, 1000, 2000, 4000):
        d = nearly_sorted(n, 10)
        c_first = quick_sort(d[:], "first")
        c_med = quick_sort(d[:], "median3")
        c_rand = quick_sort(d[:], "random")
        rows.append((n, c_first, c_med, c_rand))
        print(f"{n:>8} {c_first:>14,} {n * (n - 1) // 2:>14,} {c_med:>13,} {c_rand:>10,} {int(n * math.log2(n)):>10,}")

    n = 100_000
    print("\nPRODUCTION ESTIMATE, n = 100,000 nearly sorted sellers")
    print(f"  First-pivot worst case n(n-1)/2   = {n * (n - 1) // 2:,}")
    print(f"  Best case ~ n lg n                = {n * math.log2(n):,.0f}")
    print(f"  Expected random/median ~ 2 n ln n = {2 * n * math.log(n):,.0f}")
    d = nearly_sorted(n, 10)
    print(f"  Measured median-of-three (n=100,000): {quick_sort(d[:], 'median3'):,} comparisons")
    print(f"  Measured random pivot    (n=100,000): {quick_sort(d[:], 'random'):,} comparisons")
