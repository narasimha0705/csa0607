"""
Module 3 - Order Lookup (Binary Search, first occurrence)
Requires the sorted list produced by Module 1.
"""
import math


def binary_search_basic(a, key):
    """Standard search: returns ANY index holding key (not guaranteed first). Returns (index, comparisons)."""
    lo, hi, count = 0, len(a) - 1, 0
    while lo <= hi:
        mid = (lo + hi) // 2
        count += 1
        if a[mid][0] == key:
            return mid, count
        elif a[mid][0] < key:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1, count


def binary_search_first(a, key, trace=None):
    """Modified search: returns the FIRST index whose timestamp == key. Returns (index, comparisons).
    Invariant: the first occurrence (if any) lies in a[lo..hi]. hi is kept at mid on a match."""
    lo, hi, count = 0, len(a) - 1, 0
    while lo < hi:
        mid = (lo + hi) // 2
        count += 1
        if trace is not None:
            trace.append(f"lo={lo} hi={hi} mid={mid} a[mid]={a[mid][0]}")
        if a[mid][0] < key:
            lo = mid + 1
        else:                       # a[mid] >= key : answer is at mid or to its left
            hi = mid
    if a and a[lo][0] == key:
        return lo, count
    return -1, count


if __name__ == "__main__":
    # output of Module 1
    orders = [(101, "O4"), (102, "O2"), (102, "O5"), (103, "O6"), (105, "O1"), (105, "O3")]
    print("SORTED ORDERS:", orders)
    for key in (102, 105, 101, 104):
        trace = []
        idx, c = binary_search_first(orders, key, trace)
        basic_idx, basic_c = binary_search_basic(orders, key)
        print(f"\nSearch timestamp {key}")
        print("  trace:", " | ".join(trace))
        print(f"  FIRST-occurrence search -> index {idx}"
              f"{' (' + orders[idx][1] + ')' if idx >= 0 else ' (not found)'}, comparisons = {c}")
        print(f"  basic search            -> index {basic_idx}"
              f"{' (' + orders[basic_idx][1] + ')' if basic_idx >= 0 else ' (not found)'}, comparisons = {basic_c}")

    print("\nTHEORETICAL CALCULATION FOR n = 10,000,000")
    n = 10_000_000
    print(f"  log2(n) = {math.log2(n):.4f}")
    print(f"  Max comparisons floor(lg n)+1 = {math.floor(math.log2(n)) + 1}")
    print(f"  Linear scan worst case        = {n:,}")
    print(f"  Speed-up                      = {n / (math.floor(math.log2(n)) + 1):,.0f} x")

    # empirical check on a large sorted list
    big = [(t // 3, i) for i, t in enumerate(range(n))]
    worst = 0
    for key in (0, 1, 777, big[-1][0], big[-1][0] + 5, -1):
        _, c = binary_search_first(big, key)
        worst = max(worst, c)
    print(f"  Measured worst comparisons on 10,000,000 sorted orders (6 probes): {worst}")
