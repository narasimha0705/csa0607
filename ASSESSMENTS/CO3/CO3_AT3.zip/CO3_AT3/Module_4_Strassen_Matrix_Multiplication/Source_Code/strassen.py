"""
Module 4 - Recommendation Scores (Strassen's matrix multiplication + practical hybrid)
Pure-Python lists; counts scalar multiplications so results can be compared with n^3.
"""
import math

mult_count = 0


def conventional(A, B):
    global mult_count
    n = len(A)
    C = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            s = 0
            for k in range(n):
                s += A[i][k] * B[k][j]
                mult_count += 1
            C[i][j] = s
    return C


def add(A, B):
    return [[x + y for x, y in zip(r, s)] for r, s in zip(A, B)]


def sub(A, B):
    return [[x - y for x, y in zip(r, s)] for r, s in zip(A, B)]


def split(M):
    h = len(M) // 2
    return ([r[:h] for r in M[:h]], [r[h:] for r in M[:h]],
            [r[:h] for r in M[h:]], [r[h:] for r in M[h:]])


def join(C11, C12, C21, C22):
    return [a + b for a, b in zip(C11, C12)] + [a + b for a, b in zip(C21, C22)]


def strassen(A, B, cutoff=1):
    """n must be a power of two. cutoff=1 -> pure Strassen; cutoff>1 -> hybrid (conventional below cutoff)."""
    global mult_count
    n = len(A)
    if n <= cutoff:
        return conventional(A, B)
    A11, A12, A21, A22 = split(A)               # DIVIDE
    B11, B12, B21, B22 = split(B)
    M1 = strassen(add(A11, A22), add(B11, B22), cutoff)    # CONQUER: 7 products
    M2 = strassen(add(A21, A22), B11, cutoff)
    M3 = strassen(A11, sub(B12, B22), cutoff)
    M4 = strassen(A22, sub(B21, B11), cutoff)
    M5 = strassen(add(A11, A12), B22, cutoff)
    M6 = strassen(sub(A21, A11), add(B11, B12), cutoff)
    M7 = strassen(sub(A12, A22), add(B21, B22), cutoff)
    C11 = add(sub(add(M1, M4), M5), M7)         # COMBINE
    C12 = add(M3, M5)
    C21 = add(M2, M4)
    C22 = add(add(sub(M1, M2), M3), M6)
    return join(C11, C12, C21, C22)


def strassen_demo():
    A = [[1, 7], [3, 5]]
    B = [[1, 3], [7, 5]]
    a11, a12, a21, a22 = A[0][0], A[0][1], A[1][0], A[1][1]
    b11, b12, b21, b22 = B[0][0], B[0][1], B[1][0], B[1][1]
    M1 = (a11 + a22) * (b11 + b22)
    M2 = (a21 + a22) * b11
    M3 = a11 * (b12 - b22)
    M4 = a22 * (b21 - b11)
    M5 = (a11 + a12) * b22
    M6 = (a21 - a11) * (b11 + b12)
    M7 = (a12 - a22) * (b21 + b22)
    print("A =", A, " B =", B)
    print(f"M1=(a11+a22)(b11+b22)=({a11}+{a22})({b11}+{b22}) = {M1}")
    print(f"M2=(a21+a22)b11      =({a21}+{a22})({b11})      = {M2}")
    print(f"M3=a11(b12-b22)      ={a11}({b12}-{b22})        = {M3}")
    print(f"M4=a22(b21-b11)      ={a22}({b21}-{b11})        = {M4}")
    print(f"M5=(a11+a12)b22      =({a11}+{a12})({b22})      = {M5}")
    print(f"M6=(a21-a11)(b11+b12)=({a21}-{a11})({b11}+{b12}) = {M6}")
    print(f"M7=(a12-a22)(b21+b22)=({a12}-{a22})({b21}+{b22}) = {M7}")
    C11, C12, C21, C22 = M1 + M4 - M5 + M7, M3 + M5, M2 + M4, M1 - M2 + M3 + M6
    print(f"C11=M1+M4-M5+M7 = {M1}+{M4}-{M5}+{M7} = {C11}")
    print(f"C12=M3+M5       = ({M3})+{M5} = {C12}")
    print(f"C21=M2+M4       = {M2}+{M4} = {C21}")
    print(f"C22=M1-M2+M3+M6 = {M1}-({M2})+({M3})+{M6} = {C22}")
    strassen_result = [[C11, C12], [C21, C22]]
    conv = conventional(A, B)
    print("Strassen result    :", strassen_result)
    print("Conventional result:", conv)
    print("Match:", strassen_result == conv)


if __name__ == "__main__":
    import random
    strassen_demo()

    print("\nMEASURED SCALAR MULTIPLICATIONS (random matrices, results verified against conventional)")
    print(f"{'n':>5} {'conventional n^3':>18} {'Strassen (cutoff 1)':>21} {'hybrid (cutoff 8)':>19} {'correct':>8}")
    for n in (2, 4, 8, 16, 32, 64):
        A = [[random.randint(-9, 9) for _ in range(n)] for _ in range(n)]
        B = [[random.randint(-9, 9) for _ in range(n)] for _ in range(n)]
        mult_count = 0
        ref = conventional(A, B)
        conv_c = mult_count
        mult_count = 0
        s1 = strassen(A, B, 1)
        s_c = mult_count
        mult_count = 0
        s2 = strassen(A, B, 8)
        h_c = mult_count
        print(f"{n:>5} {conv_c:>18,} {s_c:>21,} {h_c:>19,} {str(s1 == ref and s2 == ref):>8}")

    print("\nPRODUCTION CALCULATION, n = 1,024 = 2^10")
    n = 1024
    k = int(math.log2(n))
    conv_m = n ** 3
    st_m = 7 ** k
    print(f"  exponent log2(7)           = {math.log2(7):.4f}")
    print(f"  Conventional n^3           = {conv_m:,}")
    print(f"  Strassen 7^10 = n^2.807    = {st_m:,}")
    print(f"  Saving                     = {conv_m - st_m:,} multiplications ({100 * (1 - st_m / conv_m):.1f}%)")
    print(f"  Ratio conventional/Strassen= {conv_m / st_m:.3f}")
    adds = 6 * (7 ** k - 4 ** k)
    print(f"  Strassen additions 6(7^10-4^10) = {adds:,}  vs conventional n^3-n^2 = {n ** 3 - n ** 2:,}")
    print(f"  Total ops Strassen (mult+add)   = {st_m + adds:,}   conventional = {2 * n ** 3 - n ** 2:,}")
    print("\nHYBRID (switch to conventional at size c)")
    for c in (1, 4, 8, 16, 32, 64, 128, 256):
        subs = 7 ** int(math.log2(n // c))
        mults = subs * c ** 3
        adds_c = 18 * sum(7 ** i * (n // 2 ** (i + 1)) ** 2 for i in range(int(math.log2(n // c))))
        conv_adds = subs * (c ** 3 - c ** 2)
        print(f"  cutoff {c:>4}: {subs:>9,} sub-multiplications of size {c:>4}; "
              f"mults = {mults:>14,}; total ops = {mults + adds_c + conv_adds:>14,}")
    print(f"\n  Theoretical arithmetic break-even size n0 where Strassen beats conventional: 15")
