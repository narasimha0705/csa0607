# CO3_AT3 – Divide-and-Conquer Engine of KartIQ (CSA06 Design and Analysis of Algorithms)

Individual case study. Four modules, each solved with a divide-and-conquer algorithm.

| Module | Algorithm | Run |
|---|---|---|
| 1 – Nightly Order Consolidation | Stable Merge Sort | `python Module_1_Merge_Sort/Source_Code/merge_sort.py` |
| 2 – Live Seller Leaderboard | Quick Sort (first pivot vs median-of-three / random) | `python Module_2_Quick_Sort/Source_Code/quick_sort.py` |
| 3 – Order Lookup | Binary Search (first occurrence) | `python Module_3_Binary_Search/Source_Code/binary_search.py` |
| 4 – Recommendation Scores | Strassen + hybrid cut-off | `python Module_4_Strassen_Matrix_Multiplication/Source_Code/strassen.py` |

Requirements: Python 3.9+ (charts only: `pip install matplotlib`, then `python Supporting_Files/make_charts.py` from this folder).

## Folder guide
- `Module_x/Pseudocode/` – separate pseudocode for each algorithm
- `Module_x/Source_Code/` – complete executable program using the sample datasets
- `Module_x/Report/` – saved program output and graphs
- `Final_Design_and_Analysis/` – the full case-study report (Word and PDF)
- `Supporting_Files/` – chart generator and all graphs

## Key results
- Merge Sort: sample trace verified stable; ~2.23 x 10^8 comparisons for 10,000,000 orders.
- Quick Sort: first-element pivot is quadratic on nearly sorted data (5.0 x 10^9 worst case for 100,000 sellers); median-of-three needs ~2.07 x 10^6 comparisons.
- Binary Search: at most 24 comparisons for 10,000,000 orders; returns the first order with a given timestamp.
- Strassen: 282,475,249 vs 1,073,741,824 multiplications for n = 1,024; hybrid cut-off recommended.
