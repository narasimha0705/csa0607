"""
Module 1 - Nightly Order Consolidation (Stable Merge Sort)
KartIQ case study, CO3. Sorts orders by timestamp; equal timestamps keep arrival order.
"""
import math

comparisons = 0


def merge(a, lo, mid, hi, aux, trace, depth):
    """COMBINE: merge sorted a[lo..mid] and a[mid+1..hi]. '<=' keeps the LEFT item first => stable."""
    global comparisons
    left, right = a[lo:mid + 1], a[mid + 1:hi + 1]
    i = j = 0
    k = lo
    while i < len(left) and j < len(right):
        comparisons += 1
        if left[i][0] <= right[j][0]:          # equal timestamps: take LEFT (earlier arrival)
            a[k] = left[i]; i += 1
        else:
            a[k] = right[j]; j += 1
        k += 1
    while i < len(left):
        a[k] = left[i]; i += 1; k += 1
    while j < len(right):
        a[k] = right[j]; j += 1; k += 1
    trace.append(f"{'  ' * depth}MERGE {fmt(left)} + {fmt(right)} -> {fmt(a[lo:hi + 1])}")


def fmt(items):
    return "[" + ", ".join(f"({t},{o})" for t, o in items) + "]"


def merge_sort(a, lo, hi, aux, trace, depth=0):
    if lo >= hi:                                # base case: one element is sorted
        return
    mid = (lo + hi) // 2                        # DIVIDE
    trace.append(f"{'  ' * depth}DIVIDE a[{lo}..{hi}] = {fmt(a[lo:hi + 1])}")
    merge_sort(a, lo, mid, aux, trace, depth + 1)       # CONQUER left
    merge_sort(a, mid + 1, hi, aux, trace, depth + 1)   # CONQUER right
    merge(a, lo, mid, hi, aux, trace, depth)            # COMBINE


def stable_check(original, result):
    """Equal timestamps must appear in the same relative order as in the input."""
    pos = {oid: idx for idx, (_, oid) in enumerate(original)}
    for x, y in zip(result, result[1:]):
        if x[0] == y[0] and pos[x[1]] > pos[y[1]]:
            return False
    return True


def k_way_merge_demo(runs):
    """External-sort idea: merge already-sorted runs with a heap; ties broken by run number => stable."""
    import heapq
    heap = [(run[0][0], r, 0) for r, run in enumerate(runs) if run]
    heapq.heapify(heap)
    out = []
    while heap:
        ts, r, i = heapq.heappop(heap)
        out.append(runs[r][i])
        if i + 1 < len(runs[r]):
            heapq.heappush(heap, (runs[r][i + 1][0], r, i + 1))
    return out


if __name__ == "__main__":
    orders = [(105, "O1"), (102, "O2"), (105, "O3"), (101, "O4"), (102, "O5"), (103, "O6")]
    data = orders[:]
    trace = []
    merge_sort(data, 0, len(data) - 1, None, trace)
    print("INPUT :", fmt(orders))
    print("\nEXECUTION TRACE (divide / merge)")
    print("\n".join(trace))
    print("\nOUTPUT:", fmt(data))
    print("Comparisons made:", comparisons)
    print("Stable (equal timestamps keep arrival order):", stable_check(orders, data))
    print("  102 -> O2 before O5 :", [o for t, o in data if t == 102])
    print("  105 -> O1 before O3 :", [o for t, o in data if t == 105])

    print("\nTHEORETICAL ESTIMATES FOR n = 10,000,000")
    n = 10_000_000
    lg = math.log2(n)
    c = math.ceil(lg)
    print(f"  log2(n)                       = {lg:.4f}")
    print(f"  n log2 n (approx.)            = {n * lg:,.0f}")
    print(f"  Worst case n*ceil(lg n)-2^ceil(lg n)+1 = {n * c - 2 ** c + 1:,}")
    print(f"  Best case ~ (n/2) lg n        = {n / 2 * lg:,.0f}")
    for rec in (16, 100):
        print(f"  Memory at {rec:>3} B/record: data {n * rec / 1e6:,.0f} MB + buffer {n * rec / 1e6:,.0f} MB"
              f" = {2 * n * rec / 1e6:,.0f} MB")

    print("\nEXTERNAL MERGE DEMO (3 sorted runs, tie -> earlier run first)")
    runs = [[(101, "O4"), (105, "O1")], [(102, "O2"), (105, "O3")], [(102, "O5"), (103, "O6")]]
    print(" ", fmt(k_way_merge_demo(runs)))
