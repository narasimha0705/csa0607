"""Generates the comparison graphs used in the report (run from the CO3_AT3 folder)."""
import importlib.util
import math
import random
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = "Supporting_Files/charts/"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


qs = load("Module_2_Quick_Sort/Source_Code/quick_sort.py", "qs")
st = load("Module_4_Strassen_Matrix_Multiplication/Source_Code/strassen.py", "st")


def ms_count(a):
    cnt = 0

    def rec(x):
        nonlocal cnt
        if len(x) <= 1:
            return x
        m = len(x) // 2
        l, r = rec(x[:m]), rec(x[m:])
        out, i, j = [], 0, 0
        while i < len(l) and j < len(r):
            cnt += 1
            if l[i] <= r[j]:
                out.append(l[i]); i += 1
            else:
                out.append(r[j]); j += 1
        return out + l[i:] + r[j:]
    rec(a)
    return cnt


plt.rcParams.update({"font.size": 10, "axes.grid": True, "grid.alpha": .3})

# 1. Merge sort
ns = [2 ** k for k in range(4, 17)]
measured = [ms_count([random.random() for _ in range(n)]) for n in ns]
fig, ax = plt.subplots(figsize=(6.4, 3.8))
ax.plot(ns, measured, "o-", label="Measured comparisons (random input)")
ax.plot(ns, [n * math.log2(n) for n in ns], "--", label="n log2 n")
ax.plot(ns, [n * math.log2(n) - n + 1 for n in ns], ":", label="n log2 n - n + 1 (worst case, n = 2^k)")
ax.set_xscale("log", base=2); ax.set_yscale("log")
ax.set_xlabel("n (orders)"); ax.set_ylabel("comparisons"); ax.set_title("Merge Sort: comparisons grow as n log n")
ax.legend(); fig.tight_layout(); fig.savefig(OUT + "merge_sort_growth.png", dpi=170); plt.close(fig)

# 2. Quick sort on nearly sorted data
ns = [250, 500, 1000, 2000, 4000]
rows = {"first": [], "median3": [], "random": []}
for n in ns:
    d = qs.nearly_sorted(n, 10)
    for k in rows:
        rows[k].append(qs.quick_sort(d[:], k))
fig, ax = plt.subplots(figsize=(6.4, 3.8))
ax.plot(ns, rows["first"], "o-", color="#c0392b", label="First-element pivot (current)")
ax.plot(ns, rows["random"], "s-", color="#2874a6", label="Random pivot")
ax.plot(ns, rows["median3"], "^-", color="#1e8449", label="Median-of-three pivot")
ax.plot(ns, [n * math.log2(n) for n in ns], "k--", label="n log2 n")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("n (sellers)"); ax.set_ylabel("comparisons"); ax.set_title("Quick Sort on nearly sorted scores")
ax.legend(); fig.tight_layout(); fig.savefig(OUT + "quick_sort_pivots.png", dpi=170); plt.close(fig)

# 3. Binary vs linear
ns = [10 ** k for k in range(1, 8)]
fig, ax = plt.subplots(figsize=(6.4, 3.8))
ax.plot(ns, ns, "o-", color="#c0392b", label="Linear scan (worst case n)")
ax.plot(ns, [math.floor(math.log2(n)) + 1 for n in ns], "s-", color="#1e8449", label="Binary search floor(lg n)+1")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("n (orders)"); ax.set_ylabel("worst-case comparisons"); ax.set_title("Order lookup: binary vs linear search")
ax.legend(); fig.tight_layout(); fig.savefig(OUT + "binary_vs_linear.png", dpi=170); plt.close(fig)

# 4. Strassen
ks = list(range(1, 11))
ns = [2 ** k for k in ks]
fig, ax = plt.subplots(figsize=(6.4, 3.8))
ax.plot(ns, [n ** 3 for n in ns], "o-", color="#c0392b", label="Conventional n^3")
ax.plot(ns, [7 ** k for k in ks], "s-", color="#1e8449", label="Strassen 7^k (n^2.807)")
ax.set_xscale("log", base=2); ax.set_yscale("log")
ax.set_xlabel("n"); ax.set_ylabel("scalar multiplications"); ax.set_title("Scalar multiplications: conventional vs Strassen")
ax.legend(); fig.tight_layout(); fig.savefig(OUT + "strassen_multiplications.png", dpi=170); plt.close(fig)

# 5. Hybrid total operations at n = 1024
n = 1024
cuts = [1, 4, 8, 16, 32, 64, 128, 256, 1024]
tot = []
for c in cuts:
    L = int(math.log2(n // c))
    subs = 7 ** L
    adds = 18 * sum(7 ** i * (n // 2 ** (i + 1)) ** 2 for i in range(L))
    tot.append(((subs * c ** 3) + adds + subs * (c ** 3 - c ** 2)) / 1e9)
fig, ax = plt.subplots(figsize=(6.4, 3.8))
bars = ax.bar([str(c) if c < 1024 else "1024\n(conv.)" for c in cuts], tot,
              color=["#c0392b" if c in (1, 1024) else "#2874a6" for c in cuts])
ax.set_xlabel("cut-off size (switch to conventional at or below)"); ax.set_ylabel("total arithmetic operations (billions)")
ax.set_title("Hybrid Strassen, n = 1,024: total additions + multiplications")
for b, v in zip(bars, tot):
    ax.text(b.get_x() + b.get_width() / 2, v + .03, f"{v:.2f}", ha="center", fontsize=8)
fig.tight_layout(); fig.savefig(OUT + "strassen_hybrid_cutoff.png", dpi=170); plt.close(fig)
print("charts written")
