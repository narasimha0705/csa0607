# CO2 Debugging and Optimisation – SentinelOps SOC Alert-Triage Module

This repository is a starter template for the individual CO2 assignment.

## Required work
1. **Reproduce and identify defects:** document all nine defects in the supplied SentinelOps module.
2. **Debug systematically:** explain root causes, apply one correction at a time, retain traces, and test boundary cases.
3. **Optimise without changing outputs:** address alert sorting, repeated blocklist lookup, signature scanning, and closest-pair pruning.
4. **Analyse performance:** compare before/after complexity and include the required experiments:
   - Distance computations for at least three input sizes between 1,000 and 8,000.
   - Insertion-sort comparisons for nearly sorted and random alert inputs.
5. **Submit production-quality work:** include documented code, comments, a test harness, and the GitHub repository link through Google Classroom.

## Repository layout
- `Pseudocode/` – algorithms and pseudocode.
- `Source_Code/` – original/reproduced and corrected/optimised implementation.
- `Report/` – defect analysis, debugging log, complexity analysis, experiment results, and conclusion.
- `Supporting_Files/` – datasets, execution logs, screenshots, graphs, and tables.

## Suggested files
- `Pseudocode/`: `algorithm_pseudocode.md`
- `Source_Code/`: `sentinelops_original.py`, `sentinelops_corrected.py`, `test_sentinelops.py`
- `Report/`: `CO2_assignment_report.md` or a PDF report
- `Supporting_Files/`: evidence for tests and performance experiments

## Important
This ZIP contains only the folder structure and starter placeholders. It does **not** contain the completed defect fixes, implementation, measured results, screenshots, or final report. Add your own verified work before submission.
