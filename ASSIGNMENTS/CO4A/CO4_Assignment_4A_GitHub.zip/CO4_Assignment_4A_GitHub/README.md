# CO4 Assignment 4A – Algorithmic Design Through Pseudocode

**Course:** CSA06 – Design and Analysis of Algorithms  
**Assignment:** Assignment 4 – CO4  
**Outcome:** Solve optimization problems using Dynamic Programming and Greedy strategies

## Included
- `Report/CO4_Assignment_4A_Report.pdf` — report with problem analysis, pseudocode, manual traces, calculations, challenge cases, and conclusion for all six tasks.
- `Pseudocode/CO4_Assignment_4A_Pseudocode.pdf` — pseudocode companion for Tasks 1–6.

## Tasks Covered
1. Fractional Knapsack – algorithm design review
2. Job Sequencing with Deadlines – greedy strategy
3. 0/1 Knapsack – dynamic programming
4. Word Break – defect diagnosis and repair
5. Dijkstra, Bellman-Ford, and Floyd shortest paths
6. Energy-Aware Job Scheduling – compulsory design challenge

## Note
The supplied assignment sheet states that this is a pseudocode/design assignment and programming-language implementations are not required. Therefore, this repository contains pseudocode and manual analysis PDFs rather than executable source code or run screenshots.
