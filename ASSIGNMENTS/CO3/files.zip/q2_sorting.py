"""
Q2 - The Quality of Decomposition in Sorting
Merge Sort vs Quick Sort.  Quick Sort pivot strategy (stated clearly):
    PIVOT = FIRST ELEMENT of the current sub-array.
    PARTITION = stable: elements < pivot go left, elements >= pivot go right, relative order kept
                (uses a temporary buffer, so the input shape that produces a given split is easy to design).
Instrumented: comparisons, partition sizes, maximum recursion depth.
Run: python q2_sorting.py   (writes results_q2.json)
"""
import json
import math
import random

random.seed(7)


# ------------------------------------------------------------------ Merge Sort
def merge_sort(a):
    """Returns (sorted list, comparisons, recursion depth, list of (left,right) split sizes at depth<=3)."""
    stats = {"cmp": 0, "depth": 0, "splits": []}

    def rec(x, depth):
        stats["depth"] = max(stats["depth"], depth)
        n = len(x)
        if n <= 1:
            return x
        mid = n // 2                                   # DIVIDE: always the middle
        if depth <= 3:
            stats["splits"].append((depth, mid, n - mid))
        l, r = rec(x[:mid], depth + 1), rec(x[mid:], depth + 1)
        out, i, j = [], 0, 0                           # COMBINE: merge
        while i < len(l) and j < len(r):
            stats["cmp"] += 1
            if l[i] <= r[j]:
                out.append(l[i]); i += 1
            else:
                out.append(r[j]); j += 1
        out.extend(l[i:]); out.extend(r[j:])
        return out

    res = rec(list(a), 1)
    return res, stats["cmp"], stats["depth"], stats["splits"]


# ------------------------------------------------------------------ Quick Sort
def quick_sort(a, record_limit=8):
    """Returns (sorted list, comparisons, max depth, first partition records, all-partition summary)."""
    arr = list(a)
    cmp_count = 0
    max_depth = 0
    records = []                     # (depth, size, left, right) for the first few partitions processed
    worst_ratio = 0.0
    stack = [(0, len(arr), 1)]       # explicit stack: (lo, hi, depth) -> no Python recursion limit problems
    partitions = 0
    while stack:
        lo, hi, depth = stack.pop()
        size = hi - lo
        if size <= 0:
            continue
        max_depth = max(max_depth, depth)
        if size == 1:
            continue
        pivot = arr[lo]                                  # pivot strategy: first element
        seg = arr[lo + 1:hi]
        cmp_count += size - 1                            # every other element is compared with the pivot
        left = [x for x in seg if x < pivot]
        right = [x for x in seg if x >= pivot]
        arr[lo:hi] = left + [pivot] + right
        p = lo + len(left)
        partitions += 1
        if len(records) < record_limit:
            records.append((depth, size, len(left), len(right)))
        worst_ratio = max(worst_ratio, max(len(left), len(right)) / size)
        stack.append((p + 1, hi, depth + 1))
        stack.append((lo, p, depth + 1))
    return arr, cmp_count, max_depth, records, {"partitions": partitions, "worst_ratio": worst_ratio}


# ------------------------------------------------------------------ input design
def build_ratio_input(values, ratio):
    """Design an input for which the FIRST-ELEMENT pivot sends `ratio` of the remaining elements to the left
    at EVERY level. values must be sorted ascending. ratio=0.5 -> balanced, ratio=0 -> sorted input."""
    n = len(values)
    if n <= 1:
        return list(values)
    idx = min(n - 1, int(ratio * (n - 1)))               # rank of the pivot inside this block
    pivot = values[idx]
    left = build_ratio_input(values[:idx], ratio)
    right = build_ratio_input(values[idx + 1:], ratio)
    return [pivot] + left + right                        # stable partition keeps both blocks intact


def lg(n):
    return math.log2(n)


def main():
    res = {"demo": {}, "table": [], "ratio_table": [], "merge": []}

    # ----- small worked example (n = 15) -----
    n = 15
    vals = list(range(1, n + 1))
    balanced = build_ratio_input(vals, 0.5)
    print("WORKED EXAMPLE, n = 15")
    print("  balanced input  :", balanced)
    _, c, d, rec, summ = quick_sort(balanced, 6)
    print(f"  Quick Sort: comparisons={c}, max depth={d}, first partitions (depth,size,left,right)={rec}")
    res["demo"]["balanced"] = {"input": balanced, "cmp": c, "depth": d, "records": rec}
    srt = vals[:]
    _, c, d, rec, summ = quick_sort(srt, 6)
    print("  sorted input    :", srt)
    print(f"  Quick Sort: comparisons={c}, max depth={d}, first partitions (depth,size,left,right)={rec}")
    res["demo"]["sorted"] = {"input": srt, "cmp": c, "depth": d, "records": rec}
    _, c, d, splits = merge_sort(balanced)
    print(f"  Merge Sort (any input of 15): comparisons<=, observed={c}, depth={d}, splits(depth,left,right)={splits}")

    # ----- main experiment -----
    print("\nQUICK SORT (first-element pivot) - designed inputs, comparisons / max depth / worst split")
    hdr = f"{'n':>6} {'input':<22} {'comparisons':>12} {'max depth':>10} {'worst split %':>14} {'n lg n':>10} {'n(n-1)/2':>11}"
    print(hdr)
    for n in [256, 1024, 2048, 4096]:
        vals = list(range(n))
        cases = {
            "balanced (50:50)": build_ratio_input(vals, 0.5),
            "random permutation": random.sample(vals, n),
            "ascending (0:100)": vals[:],
            "descending (100:0)": vals[::-1],
        }
        for name, a in cases.items():
            out, c, d, _, summ = quick_sort(a)
            assert out == vals
            row = {"n": n, "input": name, "cmp": c, "depth": d, "worst_ratio": summ["worst_ratio"]}
            res["table"].append(row)
            print(f"{n:>6} {name:<22} {c:>12,} {d:>10} {100 * summ['worst_ratio']:>13.1f}% {int(n * lg(n)):>10,} {n * (n - 1) // 2:>11,}")
        print()

    print("EFFECT OF SPLIT RATIO on recursion depth (n = 4096, designed input; predicted depth ~ ln n / ln(1/q), q = larger side)")
    print(f"{'split':>10} {'comparisons':>12} {'max depth':>10} {'predicted depth':>16} {'cmp / (n lg n)':>15}")
    n = 4096
    vals = list(range(n))
    for ratio in [0.5, 0.25, 0.1, 0.05, 0.01, 0.0]:
        a = build_ratio_input(vals, ratio)
        out, c, d, _, summ = quick_sort(a)
        q = max(ratio, 1 - ratio)
        pred = math.log(n) / math.log(1 / q) if q < 1 else float("inf")
        label = f"{int(ratio * 100)}:{100 - int(ratio * 100)}"
        res["ratio_table"].append({"split": label, "cmp": c, "depth": d, "pred": None if q >= 1 else pred})
        print(f"{label:>10} {c:>12,} {d:>10} {pred:>16.1f} {c / (n * lg(n)):>15.2f}")

    print("\nMERGE SORT - same sizes, ANY input (structure never changes)")
    print(f"{'n':>6} {'input':<22} {'comparisons':>12} {'depth':>6} {'ceil(lg n)+1':>13}")
    for n in [256, 1024, 2048, 4096]:
        vals = list(range(n))
        for name, a in {"random permutation": random.sample(vals, n), "ascending": vals[:], "descending": vals[::-1]}.items():
            out, c, d, _ = merge_sort(a)
            assert out == vals
            res["merge"].append({"n": n, "input": name, "cmp": c, "depth": d})
            print(f"{n:>6} {name:<22} {c:>12,} {d:>6} {math.ceil(lg(n)) + 1:>13}")
    json.dump(res, open("results_q2.json", "w"), indent=1)


if __name__ == "__main__":
    main()
