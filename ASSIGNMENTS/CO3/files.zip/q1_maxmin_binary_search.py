"""
Q1 - Decomposition and Elimination in Ordered Data
Part A: Divide-and-conquer Max/Min with comparison counting
Part B: Binary search (successful / unsuccessful cases) with comparison counting
Run:  python q1_maxmin_binary_search.py      (writes results_q1.json)
"""
import json
import math
import random

random.seed(2024)


# ------------------------------------------------------------------ Part A
class Counter:
    def __init__(self):
        self.n = 0


def naive_maxmin(a, c):
    """Independent scans: finds max with n-1 comparisons then min with n-1 comparisons."""
    mx = a[0]
    for x in a[1:]:
        c.n += 1
        if x > mx:
            mx = x
    mn = a[0]
    for x in a[1:]:
        c.n += 1
        if x < mn:
            mn = x
    return mn, mx


def dc_maxmin(a, lo, hi, c):
    """Returns (min, max) of a[lo..hi]."""
    if lo == hi:                           # base case 1: one element -> no comparison
        return a[lo], a[lo]
    if hi == lo + 1:                       # base case 2: two elements -> ONE comparison
        c.n += 1
        return (a[lo], a[hi]) if a[lo] < a[hi] else (a[hi], a[lo])
    mid = (lo + hi) // 2                   # DIVIDE
    mn1, mx1 = dc_maxmin(a, lo, mid, c)    # CONQUER
    mn2, mx2 = dc_maxmin(a, mid + 1, hi, c)
    c.n += 1                               # COMBINE: compare the two minima
    mn = mn1 if mn1 < mn2 else mn2
    c.n += 1                               #          compare the two maxima
    mx = mx1 if mx1 > mx2 else mx2
    return mn, mx


def pairing_maxmin(a, c):
    """Tournament / pairing variant: compare elements in pairs first, then min among the losers and
    max among the winners. Achieves ceil(3n/2)-2 for EVERY n."""
    mins, maxs = [], []
    for i in range(0, len(a) - 1, 2):
        c.n += 1
        if a[i] < a[i + 1]:
            mins.append(a[i]); maxs.append(a[i + 1])
        else:
            mins.append(a[i + 1]); maxs.append(a[i])
    if len(a) % 2:
        mins.append(a[-1]); maxs.append(a[-1])
    mn, mx = mins[0], maxs[0]
    for x in mins[1:]:
        c.n += 1
        if x < mn:
            mn = x
    for x in maxs[1:]:
        c.n += 1
        if x > mx:
            mx = x
    return mn, mx


def predicted_ideal(n):
    """Lower bound / best possible: ceil(3n/2) - 2."""
    return 0 if n <= 1 else math.ceil(3 * n / 2) - 2


_memo = {1: 0, 2: 1}


def predicted_recurrence(n):
    """Exact value of T(n) = T(floor(n/2)) + T(ceil(n/2)) + 2 with T(1)=0, T(2)=1 (the recursion as coded)."""
    if n not in _memo:
        _memo[n] = predicted_recurrence(n // 2) + predicted_recurrence(n - n // 2) + 2
    return _memo[n]


def part_a():
    out = {"table": [], "datasets": []}
    ok_rec = ok_pair = True
    worst_excess = (0, 0)
    for n in range(1, 2001):
        a = [random.randint(0, 10**6) for _ in range(n)]
        c, c2 = Counter(), Counter()
        r = dc_maxmin(a, 0, n - 1, c)
        r2 = pairing_maxmin(a, c2)
        ok_rec &= r == (min(a), max(a)) and c.n == predicted_recurrence(n)
        ok_pair &= r2 == (min(a), max(a)) and c2.n == predicted_ideal(n)
        if n > 1 and c.n / (1.5 * n) > worst_excess[0]:
            worst_excess = (c.n / (1.5 * n), n)
    out["recurrence_exact"], out["pairing_exact"] = ok_rec, ok_pair
    out["worst_excess_ratio"], out["worst_excess_n"] = worst_excess
    print(f"n = 1..2000: D&C count == exact recurrence T(n)=T(floor(n/2))+T(ceil(n/2))+2 : {ok_rec}")
    print(f"n = 1..2000: pairing variant count == ceil(3n/2)-2                             : {ok_pair}")
    print(f"largest observed D&C count / (3n/2) for n>1 = {worst_excess[0]:.4f} (at n = {worst_excess[1]})")

    print("\nPART A - comparisons (n elements)")
    print(f"{'n':>9} {'naive 2(n-1)':>13} {'D&C observed':>13} {'recurrence':>11} {'ceil(3n/2)-2':>13} {'pairing':>9} {'D&C-ideal':>10} {'saving %':>9}")
    for n in [2, 3, 4, 8, 10, 16, 100, 128, 1000, 1024, 10_000, 65_536, 100_000, 1_000_000]:
        a = [random.randint(0, 10**9) for _ in range(n)]
        c1, c2, c3 = Counter(), Counter(), Counter()
        r1 = naive_maxmin(a, c1)
        r2 = dc_maxmin(a, 0, n - 1, c2)
        r3 = pairing_maxmin(a, c3)
        assert r1 == r2 == r3
        ideal, rec = predicted_ideal(n), predicted_recurrence(n)
        assert c2.n == rec
        out["table"].append({"n": n, "naive": c1.n, "dc": c2.n, "rec": rec, "ideal": ideal, "pair": c3.n})
        print(f"{n:>9,} {c1.n:>13,} {c2.n:>13,} {rec:>11,} {ideal:>13,} {c3.n:>9,} {c2.n - ideal:>10,} {100 * (1 - c2.n / c1.n):>9.2f}")

    print("\nDATASET-INDEPENDENCE (n = 1000): the count depends only on n, not on the data order")
    n = 1000
    sets = {
        "random": [random.randint(0, 10**6) for _ in range(n)],
        "ascending": list(range(n)),
        "descending": list(range(n, 0, -1)),
        "all equal": [7] * n,
        "alternating": [(i % 2) * 1000 + i for i in range(n)],
        "max first, min last": [n] + list(range(1, n - 1)) + [0],
    }
    for name, a in sets.items():
        c = Counter()
        mn, mx = dc_maxmin(a, 0, n - 1, c)
        assert (mn, mx) == (min(a), max(a))
        out["datasets"].append({"name": name, "count": c.n})
        print(f"  {name:<22} min={mn:<8} max={mx:<8} comparisons={c.n}")
    return out


# ------------------------------------------------------------------ Part B
def binary_search(a, key):
    """Returns (index or -1, number of 3-way key comparisons)."""
    lo, hi, comps = 0, len(a) - 1, 0
    while lo <= hi:                        # termination: search space empty when lo > hi
        mid = lo + (hi - lo) // 2
        comps += 1                         # one three-way comparison key vs a[mid]
        if a[mid] == key:
            return mid, comps
        if a[mid] < key:
            lo = mid + 1                   # eliminate a[lo..mid]  (all <= a[mid] < key)
        else:
            hi = mid - 1                   # eliminate a[mid..hi]  (all >= a[mid] > key)
    return -1, comps


def part_b():
    out = {"small_trace": [], "scaling": []}
    # trace of one successful and one unsuccessful search
    a = [3, 8, 12, 19, 24, 31, 40, 47, 55, 63, 71]
    print("\nPART B - trace on", a)
    for key in (47, 20):
        lo, hi, step = 0, len(a) - 1, 0
        print(f"  search key {key}")
        while lo <= hi:
            mid = lo + (hi - lo) // 2
            step += 1
            verdict = "found" if a[mid] == key else ("go right" if a[mid] < key else "go left")
            print(f"    step {step}: lo={lo} hi={hi} mid={mid} a[mid]={a[mid]:<3} -> {verdict}")
            out["small_trace"].append({"key": key, "step": step, "lo": lo, "hi": hi, "mid": mid})
            if a[mid] == key:
                break
            if a[mid] < key:
                lo = mid + 1
            else:
                hi = mid - 1

    print("\nSCALING with dataset size (sorted even numbers 0,2,4,...; odd keys are absent)")
    print(f"{'n':>10} {'floor(lg n)+1':>14} | {'succ. best':>10} {'succ. avg':>10} {'succ. worst':>12} |"
          f" {'unsucc. avg':>12} {'unsucc. worst':>14} | {'linear worst n':>14}")
    for n in [7, 15, 31, 100, 1000, 1023, 10_000, 100_000, 1_000_000]:
        a = list(range(0, 2 * n, 2))
        bound = int(math.log2(n)) + 1
        if n <= 4096:
            succ_keys = a
            unsucc_keys = [k + 1 for k in a] + [-1]
        else:
            succ_keys = random.sample(a, 4000) + [a[0], a[-1], a[n // 2]]
            unsucc_keys = [k + 1 for k in random.sample(a, 4000)] + [-1, 2 * n + 1]
        s = [binary_search(a, k)[1] for k in succ_keys]
        u = [binary_search(a, k)[1] for k in unsucc_keys]
        assert all(binary_search(a, k)[0] != -1 for k in succ_keys[:50])
        assert all(binary_search(a, k)[0] == -1 for k in unsucc_keys[:50])
        row = {"n": n, "bound": bound, "s_best": min(s), "s_avg": sum(s) / len(s), "s_worst": max(s),
               "u_avg": sum(u) / len(u), "u_worst": max(u)}
        out["scaling"].append(row)
        print(f"{n:>10,} {bound:>14} | {row['s_best']:>10} {row['s_avg']:>10.2f} {row['s_worst']:>12} |"
              f" {row['u_avg']:>12.2f} {row['u_worst']:>14} | {n:>14,}")
    return out


if __name__ == "__main__":
    res = {"A": part_a(), "B": part_b()}
    json.dump(res, open("results_q1.json", "w"), indent=1)
