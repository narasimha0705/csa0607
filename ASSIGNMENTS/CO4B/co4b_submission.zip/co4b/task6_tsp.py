"""Task 6 - Travelling salesperson with the Held-Karp Dynamic Programme.
Location 0 is the distribution hub; locations 1..n are delivery points.
Subset S is a bitmask over the n delivery points (bit k-1 <-> location k); the hub is implicit in every route.
  DP[S][j] = minimum cost of a path that starts at the hub, visits exactly the points in S, and ends at j (j in S).
  Base      : DP[{j}][j] = cost[0][j]
  Recurrence: DP[S][j] = min over i in S\\{j} of DP[S\\{j}][i] + cost[i][j]
  Answer    : min over j of DP[ALL][j] + cost[j][0]      (return to hub)
"""
import itertools, math, random, sys, time, tracemalloc

INF = float("inf")


def held_karp(cost, stats=None):
    n = len(cost) - 1                                   # delivery locations
    if n < 1:
        raise ValueError("need at least one delivery location")
    full = (1 << n) - 1
    dp = [[INF] * n for _ in range(1 << n)]              # dp[mask][j-1]
    parent = [[-1] * n for _ in range(1 << n)]
    states = transitions = 0
    for j in range(n):                                   # base states: singleton subsets
        dp[1 << j][j] = cost[0][j + 1]
        states += 1
    for mask in range(1, full + 1):
        if mask & (mask - 1) == 0:
            continue                                     # singletons already initialised
        for j in range(n):
            if not mask >> j & 1:
                continue
            prev = mask ^ (1 << j)
            best, arg = INF, -1
            for i in range(n):
                if prev >> i & 1:
                    transitions += 1
                    c = dp[prev][i] + cost[i + 1][j + 1]
                    if c < best:
                        best, arg = c, i
            dp[mask][j], parent[mask][j] = best, arg
            states += 1
    best, last = INF, -1
    for j in range(n):                                   # close the tour
        c = dp[full][j] + cost[j + 1][0]
        if c < best:
            best, last = c, j
    route, mask, j = [], full, last
    while j != -1:
        route.append(j + 1)
        pj = parent[mask][j]
        mask ^= 1 << j
        j = pj
    route.reverse()
    if stats is not None:
        stats.update(states=states, transitions=transitions)
    return best, [0] + route + [0]


def brute_force(cost):
    n = len(cost) - 1
    results = []
    for perm in itertools.permutations(range(1, n + 1)):
        route = (0,) + perm + (0,)
        results.append((sum(cost[a][b] for a, b in zip(route, route[1:])), route))
    return sorted(results)


def label(route, names): return " -> ".join(names[i] for i in route)


NAMES = ["Hub", "A", "B", "C", "D", "E", "F"]
COST = [
    [0, 12, 10, 19, 8, 14, 21],
    [12, 0, 3, 7, 2, 9, 11],
    [10, 3, 0, 6, 20, 5, 17],
    [19, 7, 6, 0, 4, 8, 6],
    [8, 2, 20, 4, 0, 15, 10],
    [14, 9, 5, 8, 15, 0, 13],
    [21, 11, 17, 6, 10, 13, 0],
]


def random_instance(n, seed):
    rnd = random.Random(seed)
    m = [[0] * (n + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        for j in range(i + 1, n + 1):
            m[i][j] = m[j][i] = rnd.randint(1, 100)
    return m


if __name__ == "__main__":
    print("######## 6.3 Optimal route, hub + 6 delivery locations ########")
    print("Cost matrix:"); print("      " + "".join(f"{x:>5}" for x in NAMES))
    for nm, row in zip(NAMES, COST): print(f"{nm:>5} " + "".join(f"{v:>5}" for v in row))
    st = {}
    best, route = held_karp(COST, st)
    print("\nOptimal route:", label(route, NAMES))
    print("Visit order  :", [NAMES[i] for i in route[1:-1]])
    legs = [(NAMES[a], NAMES[b], COST[a][b]) for a, b in zip(route, route[1:])]
    print("Legs         :", ", ".join(f"{a}->{b}={c}" for a, b, c in legs))
    print("Minimum Travel Cost =", best, f"| DP states evaluated = {st['states']}, transitions = {st['transitions']}")

    print("\n######## 6.4 Validation: hub + 4 delivery locations (A..D) ########")
    small = [row[:5] for row in COST[:5]]
    ref = brute_force(small)
    print(f"Exhaustive enumeration of all 4! = {len(ref)} routes (sorted by cost):")
    for c, r in ref: print(f"  {c:>3}  {label(r, NAMES)}")
    dp_best, dp_route = held_karp(small)
    print(f"Exhaustive optimum = {ref[0][0]} ; DP result = {dp_best} via {label(dp_route, NAMES)}")
    print("MATCH" if dp_best == ref[0][0] else "MISMATCH", "| DP route cost recomputed independently =",
          sum(small[a][b] for a, b in zip(dp_route, dp_route[1:])))
    bad = 0
    for seed in range(200):
        n = random.Random(seed).randint(1, 7)
        m = random_instance(n, seed)
        if held_karp(m)[0] != brute_force(m)[0][0]: bad += 1
    print("Extra check: 200 random instances (1..7 deliveries) DP vs exhaustive, mismatches =", bad)
    one = held_karp([[0, 5], [5, 0]])
    print("Boundary n=1:", one, "(Hub -> 1 -> Hub = 10)")

    print("\n######## 6.5 State-space growth ########")
    print(f"{'n':>3}{'DP states':>12}{'n*2^(n-1)':>12}{'transitions':>14}{'subsets 2^n':>13}{'time (s)':>10}{'peak mem (MiB)':>16}{'cells n*2^n':>14}{'n! routes':>16}")
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else 15
    for n in range(4, limit + 1):
        m = random_instance(n, 100 + n)
        s = {}
        t0 = time.perf_counter(); held_karp(m, s); dt = time.perf_counter() - t0
        tracemalloc.start(); held_karp(m); peak = tracemalloc.get_traced_memory()[1] / 2**20; tracemalloc.stop()
        print(f"{n:>3}{s['states']:>12,}{n * 2**(n-1):>12,}{s['transitions']:>14,}{2**n:>13,}{dt:>10.3f}{peak:>16.2f}{n * 2**n:>14,}{math.factorial(n):>16,}")
    print("(n! column = permutations an exhaustive search must examine)")
