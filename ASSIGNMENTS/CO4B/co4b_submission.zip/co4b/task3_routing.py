"""Task 3 - Routing engine: Dijkstra, Bellman-Ford, Floyd, Warshall.
Graph = directed, weighted, adjacency list. Algorithm code is separate from the printing code."""
import heapq

INF = float("inf")
VERTICES = ["S", "A", "B", "C", "D", "E", "F", "G"]          # 8 vertices
BASE_EDGES = [                                               # 13 edges, all positive
    ("S", "A", 2), ("S", "B", 4), ("A", "C", 3), ("B", "C", 2), ("A", "D", 7),
    ("C", "D", 2), ("C", "E", 5), ("D", "F", 1), ("E", "F", 2), ("D", "G", 6),
    ("F", "G", 2), ("B", "E", 8), ("E", "G", 3),
]
NEG_EDGE = ("B", "A", -3)                                    # Stage B edge
CYCLE_EDGE = ("F", "C", -4)                                  # Stage C edge: C->D->F->C = 2+1-4 = -1


def adjacency(vertices, edges):
    adj = {v: [] for v in vertices}
    for u, v, w in edges:
        adj[u].append((v, w))
    return adj


# ------------------------------------------------------------ Dijkstra (textbook, finalise-once)
def dijkstra(vertices, edges, source):
    adj = adjacency(vertices, edges)
    dist = {v: INF for v in vertices}
    pred = {v: None for v in vertices}
    finalized, order = set(), []
    dist[source] = 0
    heap = [(0, source)]
    while heap:
        d, u = heapq.heappop(heap)
        if u in finalized:
            continue
        finalized.add(u)                       # Dijkstra's invariant: dist[u] is now FINAL
        order.append(u)
        for v, w in adj[u]:
            if v not in finalized and d + w < dist[v]:   # never revisits a finalised vertex
                dist[v] = d + w
                pred[v] = u
                heapq.heappush(heap, (dist[v], v))
    return dist, pred, order


def path_to(pred, source, target):
    if target != source and pred[target] is None:
        return None
    path = [target]
    while path[-1] != source:
        path.append(pred[path[-1]])
    return path[::-1]


# ------------------------------------------------------------ Bellman-Ford with negative-cycle detection
def bellman_ford(vertices, edges, source):
    dist = {v: INF for v in vertices}
    pred = {v: None for v in vertices}
    dist[source] = 0
    passes_used = 0
    for p in range(1, len(vertices)):                       # V-1 passes
        changed = False
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v], pred[v], changed = dist[u] + w, u, True
        passes_used = p
        if not changed:
            break
    for u, v, w in edges:                                   # V-th pass: any relaxation => negative cycle
        if dist[u] != INF and dist[u] + w < dist[v]:
            pred[v] = u
            x = v
            for _ in range(len(vertices)):                  # walk back V steps to be inside the cycle
                x = pred[x]
            cycle, y = [x], pred[x]
            while y != x:
                cycle.append(y); y = pred[y]
            cycle.append(x)
            return None, None, passes_used, cycle[::-1]
    return dist, pred, passes_used, None


# ------------------------------------------------------------ Floyd & Warshall
def floyd(vertices, edges):
    idx = {v: i for i, v in enumerate(vertices)}
    n = len(vertices)
    d = [[INF] * n for _ in range(n)]
    for i in range(n): d[i][i] = 0
    for u, v, w in edges: d[idx[u]][idx[v]] = min(d[idx[u]][idx[v]], w)
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if d[i][k] + d[k][j] < d[i][j]:
                    d[i][j] = d[i][k] + d[k][j]
    neg_cycle = any(d[i][i] < 0 for i in range(n))
    return d, neg_cycle


def warshall(vertices, edges):
    idx = {v: i for i, v in enumerate(vertices)}
    n = len(vertices)
    r = [[False] * n for _ in range(n)]
    for i in range(n): r[i][i] = True
    for u, v, _ in edges: r[idx[u]][idx[v]] = True
    for k in range(n):
        for i in range(n):
            for j in range(n):
                r[i][j] = r[i][j] or (r[i][k] and r[k][j])
    return r


# ------------------------------------------------------------ presentation
def print_dijkstra(title, vertices, edges, source):
    dist, pred, order = dijkstra(vertices, edges, source)
    print(f"\n--- {title}: Dijkstra from {source} ---")
    print("Finalisation order:", " -> ".join(order))
    print(f"{'Vertex':<7}{'Dist':>6}  {'Pred':<5} Path")
    for v in vertices:
        p = path_to(pred, source, v)
        print(f"{v:<7}{dist[v]:>6}  {str(pred[v]):<5} {' -> '.join(p) if p else 'unreachable'}")
    return dist, pred


def print_bf(title, vertices, edges, source):
    dist, pred, passes, cycle = bellman_ford(vertices, edges, source)
    print(f"\n--- {title}: Bellman-Ford from {source} ---")
    if cycle:
        print(f"NEGATIVE CYCLE DETECTED after {passes} passes (edge still relaxable in pass V={len(vertices)}).")
        print("Cycle:", " -> ".join(cycle), "| cycle weight =",
              sum(next(w for a, b, w in edges if a == x and b == y) for x, y in zip(cycle, cycle[1:])))
        print("Shortest distances are undefined (-infinity) for vertices reachable from the cycle; no distances reported.")
        return None, None
    print(f"Converged after {passes} pass(es) (limit V-1 = {len(vertices)-1}).")
    print(f"{'Vertex':<7}{'Dist':>6}  {'Pred':<5} Path")
    for v in vertices:
        p = path_to(pred, source, v)
        print(f"{v:<7}{dist[v]:>6}  {str(pred[v]):<5} {' -> '.join(p) if p else 'unreachable'}")
    return dist, pred


def print_matrix(title, vertices, m, fmt):
    print(f"\n{title}")
    print("      " + "".join(f"{v:>5}" for v in vertices))
    for v, row in zip(vertices, m):
        print(f"{v:>5} " + "".join(f"{fmt(x):>5}" for x in row))


def fw(x): return "INF" if x == INF else str(x)
def rw(x): return "1" if x else "0"


if __name__ == "__main__":
    import sys
    stage = sys.argv[1] if len(sys.argv) > 1 else "all"
    print("Vertices:", VERTICES)
    print("Edges (u,v,w):", BASE_EDGES, f"-> V={len(VERTICES)}, E={len(BASE_EDGES)}")
    if stage in ("A", "all"):
        print("\n================ STAGE A - normal routing ================")
        print_dijkstra("Stage A", VERTICES, BASE_EDGES, "S")
    if stage in ("B", "all"):
        print("\n================ STAGE B - negative edge B->A (-3) ================")
        edges_b = BASE_EDGES + [NEG_EDGE]
        dd, dp_, _ = dijkstra(VERTICES, edges_b, "S")
        print_dijkstra("Stage B", VERTICES, edges_b, "S")
        bd, bp = print_bf("Stage B", VERTICES, edges_b, "S")
        print("\nComparison Dijkstra vs Bellman-Ford:")
        for v in VERTICES:
            flag = "  <-- WRONG in Dijkstra" if dd[v] != bd[v] else ""
            print(f"  {v}: Dijkstra={dd[v]:>3}  Bellman-Ford={bd[v]:>3}{flag}")
    if stage in ("C", "all"):
        print("\n================ STAGE C - reachable negative cycle ================")
        edges_c = BASE_EDGES + [NEG_EDGE, CYCLE_EDGE]
        print_bf("Stage C", VERTICES, edges_c, "S")
        print("\nFor contrast, what an unguarded Dijkstra returns on this graph:")
        print_dijkstra("Stage C (UNSAFE)", VERTICES, edges_c, "S")
        print("\nBoundary: negative cycle NOT reachable from the source is ignored by Bellman-Ford:")
        print_bf("Stage C-unreachable (source = G, cycle is upstream)", VERTICES, edges_c, "G")
    if stage in ("D", "all"):
        print("\n================ STAGE D - all pairs ================")
        edges_b = BASE_EDGES + [NEG_EDGE]
        d, neg = floyd(VERTICES, edges_b)
        print_matrix("Floyd-Warshall shortest-path matrix (graph with B->A = -3)", VERTICES, d, fw)
        print("Negative cycle (diagonal < 0)?", neg)
        r = warshall(VERTICES, edges_b)
        print_matrix("Warshall reachability matrix (1 = row can reach column)", VERTICES, r, rw)
        d2, neg2 = floyd(VERTICES, BASE_EDGES + [NEG_EDGE, CYCLE_EDGE])
        print("\nFloyd on the negative-cycle graph: diagonal =", [d2[i][i] for i in range(len(VERTICES))],
              "-> negative cycle detected:", neg2)
        r2 = warshall(VERTICES, BASE_EDGES + [NEG_EDGE, CYCLE_EDGE])
        print_matrix("Warshall reachability on the cycle graph (C, D, F now mutually reachable)", VERTICES, r2, rw)
