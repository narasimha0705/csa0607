"""Task 2 - Greedy (fractional knapsack) vs Dynamic Programming (0/1 knapsack).
Items are (id, weight, value). Weights must be positive integers for the DP table."""
import random, sys

# ------------------------------------------------------------ Solution A: greedy
def fractional_greedy(items, capacity, ops=None):
    """Sort by value/weight, take whole items, then a fraction of the first that does not fit."""
    ops = ops if ops is not None else {}
    ops["comparisons"] = 0
    import functools
    def cmp(a, b):
        ops["comparisons"] += 1
        ra, rb = a[2] / a[1], b[2] / b[1]
        return -1 if ra > rb else (1 if ra < rb else 0)
    order = sorted(items, key=functools.cmp_to_key(cmp))
    remaining, total, chosen, steps = capacity, 0.0, [], []
    for iid, w, v in order:
        if remaining <= 0:
            break
        take = min(1.0, remaining / w)
        chosen.append((iid, take))
        total += v * take
        remaining -= w * take
        steps.append(f"ratio {v/w:.3f}: item {iid} (w={w}, v={v}) -> take {take:.3f} "
                     f"({'whole' if take == 1 else 'FRACTION'}), capacity left {remaining:g}, value so far {total:g}")
    ops["memory_cells"] = len(items)          # sorted copy of the items
    return total, chosen, steps


def greedy_01(items, capacity):
    """The SAME ratio intuition applied to 0/1: take whole items in ratio order if they fit."""
    order = sorted(items, key=lambda it: it[2] / it[1], reverse=True)
    remaining, total, chosen, steps = capacity, 0, [], []
    for iid, w, v in order:
        if w <= remaining:
            chosen.append(iid); remaining -= w; total += v
            steps.append(f"ratio {v/w:.3f}: item {iid} fits -> TAKE, capacity left {remaining}, value {total}")
        else:
            steps.append(f"ratio {v/w:.3f}: item {iid} (w={w}) does NOT fit in {remaining} -> skip")
    return total, chosen, steps


# ------------------------------------------------------------ Solution B: 0/1 DP
def knapsack_dp(items, capacity, ops=None):
    """dp[i][c] = best value using the first i items with capacity c. Full 2-D table kept for reconstruction."""
    ops = ops if ops is not None else {}
    n = len(items)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    cell_updates = 0
    for i in range(1, n + 1):
        _, w, v = items[i - 1]
        for c in range(capacity + 1):
            dp[i][c] = dp[i - 1][c]                       # skip item i
            if w <= c and dp[i - 1][c - w] + v > dp[i][c]:  # take item i
                dp[i][c] = dp[i - 1][c - w] + v
            cell_updates += 1
    chosen, c = [], capacity
    for i in range(n, 0, -1):                              # back-track
        if dp[i][c] != dp[i - 1][c]:
            chosen.append(items[i - 1][0]); c -= items[i - 1][1]
    chosen.reverse()
    ops["cells"] = cell_updates
    ops["memory_cells"] = (n + 1) * (capacity + 1)
    return dp[n][capacity], chosen, dp


def weight_of(items, ids):
    d = {i: w for i, w, _ in items}
    return sum(d[i] for i in ids)


def show_case(title, items, capacity):
    print(f"\n######## {title} ########")
    print(f"Capacity = {capacity}")
    print(f"{'ID':<4}{'Weight':>7}{'Value':>7}{'v/w':>8}")
    for iid, w, v in items:
        print(f"{iid:<4}{w:>7}{v:>7}{v/w:>8.3f}")
    ops_g, ops_d = {}, {}
    fv, fch, fsteps = fractional_greedy(items, capacity, ops_g)
    print("\nSolution A - Fractional Knapsack (greedy) decision sequence:")
    for s in fsteps: print("  ", s)
    print("  Selected:", [(i, f"{t:.3f}") for i, t in fch], "| value =", round(fv, 3))
    gv, gch, gsteps = greedy_01(items, capacity)
    print("\nSame ratio-greedy applied to 0/1 (whole items only):")
    for s in gsteps: print("  ", s)
    print("  Selected:", gch, "| weight =", weight_of(items, gch), "| value =", gv)
    dv, dch, _ = knapsack_dp(items, capacity, ops_d)
    print("\nSolution B - 0/1 Knapsack DP:")
    print("  Selected:", dch, "| weight =", weight_of(items, dch), "| value =", dv)
    print(f"  work: greedy comparisons={ops_g['comparisons']}, DP cell updates={ops_d['cells']}; "
          f"memory: greedy {ops_g['memory_cells']} cells, DP {ops_d['memory_cells']} cells")
    print(f"\nSummary: fractional(upper bound)={fv:.3f}  greedy-0/1={gv}  DP-0/1 optimum={dv}  "
          f"=> greedy-0/1 {'MATCHES' if gv == dv else 'FAILS (GreedyResult != DPOptimum)'}")
    return fv, gv, dv, gch, dch


if __name__ == "__main__":
    # 2.1 normal case: capacity is exactly filled by whole items, so greedy == DP.
    normal = [("A", 10, 60), ("B", 20, 100), ("C", 30, 90), ("D", 40, 40)]
    show_case("2.1 NORMAL CASE", normal, 30)
    # 2.2 student-designed counterexample
    bad = [("I1", 6, 13), ("I2", 5, 10), ("I3", 5, 10)]
    fv, gv, dv, gch, dch = show_case("2.2 BREAK THE GREEDY INTUITION", bad, 10)
    assert gv != dv
    print("\nFirst greedy commitment preventing the optimum: taking I1 (highest ratio 2.167, weight 6).")
    print("After it only 4 units remain, so neither I2 nor I3 (weight 5) can ever be added; the optimum {I2,I3} excludes I1.")

    # 2.3 engineering comparison: work and memory growth
    print("\n######## 2.3 ENGINEERING COMPARISON ########")
    print(f"{'n':>6}{'W':>10}{'greedy cmps':>13}{'DP cells':>12}{'greedy mem':>12}{'DP mem(cells)':>15}")
    random.seed(1)
    for n, W in [(10, 100), (100, 1000), (200, 10000), (400, 20000)]:
        items = [(f"i{k}", random.randint(1, W // 4 + 1), random.randint(1, 500)) for k in range(n)]
        og, od = {}, {}
        fractional_greedy(items, W, og); knapsack_dp(items, W, od)
        print(f"{n:>6}{W:>10}{og['comparisons']:>13}{od['cells']:>12}{og['memory_cells']:>12}{od['memory_cells']:>15}")

    print("\nSolution quality over 2000 random instances (n=8..15, W=50..200, seed=42):")
    random.seed(42)
    worst, total_ratio, fails = 1.0, 0.0, 0
    trials = 2000
    for _ in range(trials):
        n = random.randint(8, 15); W = random.randint(50, 200)
        items = [(f"i{k}", random.randint(5, 60), random.randint(5, 100)) for k in range(n)]
        gv = greedy_01(items, W)[0]; dv = knapsack_dp(items, W)[0]
        r = gv / dv if dv else 1.0
        total_ratio += r; worst = min(worst, r); fails += gv < dv
    print(f"  greedy-0/1 optimal in {trials-fails}/{trials} cases; average value ratio = {total_ratio/trials:.4f}; worst ratio = {worst:.4f}")
    # 'best single item' safeguard
    random.seed(42); worst2 = 1.0
    for _ in range(trials):
        n = random.randint(8, 15); W = random.randint(50, 200)
        items = [(f"i{k}", random.randint(5, 60), random.randint(5, 100)) for k in range(n)]
        gv = greedy_01(items, W)[0]
        single = max((v for _, w, v in items if w <= W), default=0)
        dv = knapsack_dp(items, W)[0]
        worst2 = min(worst2, max(gv, single) / dv)
    print(f"  with 'max(greedy, best single item)' safeguard the worst ratio = {worst2:.4f}")

    print("\nExtreme-capacity illustration (n=100 items, capacity W grows):")
    for W in (10**3, 10**5, 10**7):
        n = 100
        print(f"  W={W:>10,}: greedy ~ n*log2(n) = {int(n*__import__('math').log2(n))} comparisons, memory n={n} ; "
              f"DP needs n*(W+1) = {n*(W+1):,} cells")
