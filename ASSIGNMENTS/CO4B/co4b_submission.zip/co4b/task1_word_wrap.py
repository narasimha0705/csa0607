"""Task 1 - Word wrap as a document-layout engine (Dynamic Programming).

Penalty of a NON-final line with s unused spaces = s**2 ; final line = 0.
Suffix formulation:  dp[i] = minimum penalty to lay out words[i:] .
    dp[n] = 0
    dp[i] = min over j (words[i..j] fit in width W) of  line_penalty(i..j) + dp[j+1]
Assumptions: words are separated by exactly one space; a word longer than W is
an invalid input (ValueError); an empty text gives an empty layout, penalty 0.
"""
import sys

INF = float("inf")


# ---------------------------------------------------------------- algorithm
def line_length(words, i, j):
    """Characters needed by words[i..j] inclusive, one space between words."""
    return sum(len(w) for w in words[i:j + 1]) + (j - i)


def word_wrap(words, width, record_states=None):
    """Return (min_penalty, list_of_(start,end_exclusive)). Pure algorithm, no printing.
    If record_states is a list, every candidate examined is appended to it."""
    n = len(words)
    for w in words:
        if len(w) > width:
            raise ValueError(f"word '{w}' (len {len(w)}) is longer than line width {width}")
    dp = [INF] * (n + 1)
    nxt = [None] * (n + 1)
    dp[n] = 0
    for i in range(n - 1, -1, -1):
        used = -1                                   # running line length
        for j in range(i, n):
            used += len(words[j]) + 1               # add word + one separating space
            if used > width:
                break
            spaces = width - used
            penalty = 0 if j == n - 1 else spaces * spaces   # final line free
            total = penalty + dp[j + 1]
            if record_states is not None:
                record_states.append((i, j + 1, spaces, penalty, dp[j + 1], total))
            if total < dp[i]:
                dp[i] = total
                nxt[i] = j + 1
    lines, i = [], 0
    while i < n:
        lines.append((i, nxt[i]))
        i = nxt[i]
    return dp[0], lines, dp, nxt


def greedy_wrap_penalty(words, width):
    """First-fit greedy, used only to show DP vs greedy and for cross-checks."""
    n, i, total = len(words), 0, 0
    while i < n:
        j, used = i, len(words[i])
        while j + 1 < n and used + 1 + len(words[j + 1]) <= width:
            j += 1
            used += 1 + len(words[j])
        if j != n - 1:
            total += (width - used) ** 2
        i = j + 1
    return total


def brute_force_min(words, width):
    """Exhaustive reference: try every set of break points (exponential, small n only)."""
    n = len(words)
    best = INF
    def rec(i, acc):
        nonlocal best
        if acc >= best:
            return
        if i == n:
            best = acc
            return
        for j in range(i, n):
            used = line_length(words, i, j)
            if used > width:
                break
            rec(j + 1, acc + (0 if j == n - 1 else (width - used) ** 2))
    rec(0, 0)
    return best


# ---------------------------------------------------------------- output
def report(words, width, show_dp=True):
    best, lines, dp, nxt = word_wrap(words, width, record_states=[] if show_dp else None)
    print(f"\n=== Line width W = {width} ===")
    if show_dp:
        print("DP table (dp[i] = min penalty to lay out words[i:], next[i] = index where the next line starts)")
        print(f"{'i':>3} {'word':<14}{'dp[i]':>7}{'next[i]':>9}   meaning")
        for i in range(len(words)):
            print(f"{i:>3} {words[i]:<14}{dp[i]:>7}{str(nxt[i]):>9}   best layout of '{' '.join(words[i:i+3])}...' puts words[{i}:{nxt[i]}] on one line")
        print(f"{len(words):>3} {'<end>':<14}{dp[len(words)]:>7}{'-':>9}   base case: nothing left, penalty 0")
        print("\nCandidate evaluation for a few states (line = words[i:j], s = unused, pen = s^2 or 0 if final,")
        print("tail = dp[j], total = pen + tail; '*' = chosen):")
        states = []
        word_wrap(words, width, record_states=states)
        path_starts = [a for a, _ in lines]          # only show states on the optimal path
        for i in path_starts:
            for (a, b, s, p, tail, tot) in states:
                if a == i:
                    mark = "*" if nxt[i] == b else " "
                    print(f"  i={a:>2} line=words[{a}:{b}] s={s:>2} pen={p:>3} tail={tail:>4} total={tot:>4} {mark}")
    print("\nFinal layout:")
    total_check = 0
    for k, (a, b) in enumerate(lines, 1):
        txt = " ".join(words[a:b])
        s = width - len(txt)
        pen = 0 if b == len(words) else s * s
        total_check += pen
        tag = " (final line, no penalty)" if b == len(words) else ""
        print(f"  Line {k}: |{txt:<{width}}| words={b-a} unused={s} penalty={pen}{tag}")
    print(f"Minimum total penalty = {best}   (sum of line penalties = {total_check})")
    assert best == total_check
    print(f"Greedy first-fit penalty for comparison = {greedy_wrap_penalty(words, width)}")
    return best, lines


TEXT = ("Dynamic programming turns a hard layout problem into small overlapping "
        "subproblems and reuses the best answer of each one").split()

if __name__ == "__main__":
    widths = [int(x) for x in sys.argv[1:]] or [24]
    print("Words:", len(TEXT), TEXT)
    for w in widths:
        report(TEXT, w, show_dp=(len(widths) == 1))
