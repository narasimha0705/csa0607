"""Task 5 - Kruskal, Prim, Boruvka on the same undirected weighted graph, with construction traces."""
import heapq, itertools, sys

V = list("ABCDEFGH")
EDGES = [  # (u, v, w) ; list index is the 'edge id' used for deterministic tie-breaking
    ("A", "B", 4), ("B", "C", 8), ("C", "D", 7), ("D", "E", 9), ("E", "F", 10),
    ("F", "G", 2), ("G", "H", 1), ("A", "H", 11), ("B", "H", 14), ("C", "F", 6),
    ("D", "F", 13), ("A", "G", 3), ("C", "H", 5),
]
# modified graph: two ties created -> C-F = 5 (ties with C-H = 5), E-F = 9 (ties with D-E = 9)
TIED = [(u, v, {"CF": 5, "EF": 9}.get(u + v, w)) for (u, v, w) in EDGES]


class DSU:
    def __init__(self, items):
        self.p = {i: i for i in items}
    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb: return False
        self.p[rb] = ra
        return True


def key(edges, idx, ties):
    """Sort key: weight, then edge id ascending ('first') or descending ('last')."""
    return (edges[idx][2], idx if ties == "first" else -idx)


def kruskal(vertices, edges, ties="first", trace=None):
    order = sorted(range(len(edges)), key=lambda i: key(edges, i, ties))
    dsu, chosen = DSU(vertices), []
    for i in order:
        u, v, w = edges[i]
        if dsu.union(u, v):
            chosen.append(i)
            if trace is not None: trace.append(f"  consider {u}-{v} ({w}): endpoints in different components -> ACCEPT")
        elif trace is not None:
            trace.append(f"  consider {u}-{v} ({w}): same component (would close a cycle) -> reject")
        if len(chosen) == len(vertices) - 1: break
    return chosen


def prim(vertices, edges, start, ties="first", trace=None):
    adj = {v: [] for v in vertices}
    for i, (u, v, w) in enumerate(edges):
        adj[u].append((v, i)); adj[v].append((u, i))
    in_tree, chosen = {start}, []
    heap = [(key(edges, i, ties), i, v) for v, i in adj[start]]     # frontier edges
    heapq.heapify(heap)
    if trace is not None: trace.append(f"  start at {start}; tree={{{start}}}")
    while heap and len(in_tree) < len(vertices):
        _, i, v = heapq.heappop(heap)
        if v in in_tree:
            continue                                  # stale frontier edge
        u, _, w = edges[i][0], edges[i][1], edges[i][2]
        chosen.append(i); in_tree.add(v)
        if trace is not None:
            trace.append(f"  cheapest frontier edge {edges[i][0]}-{edges[i][1]} ({w}) -> add {v}; tree={{{','.join(sorted(in_tree))}}}")
        for x, j in adj[v]:
            if x not in in_tree:
                heapq.heappush(heap, (key(edges, j, ties), j, x))
    return chosen


def boruvka(vertices, edges, ties="first", trace=None):
    dsu, chosen, rnd = DSU(vertices), [], 0
    while len({dsu.find(v) for v in vertices}) > 1:
        rnd += 1
        cheapest = {}
        for i, (u, v, w) in enumerate(edges):
            ru, rv = dsu.find(u), dsu.find(v)
            if ru == rv: continue
            for r in (ru, rv):
                if r not in cheapest or key(edges, i, ties) < key(edges, cheapest[r], ties):
                    cheapest[r] = i
        if trace is not None:
            comps = {}
            for v in vertices: comps.setdefault(dsu.find(v), []).append(v)
            trace.append(f"  Round {rnd}: components {sorted(''.join(c) for c in comps.values())}")
            for r in sorted(cheapest):
                e = edges[cheapest[r]]
                trace.append(f"    component of {''.join(comps[r])}: cheapest outgoing edge {e[0]}-{e[1]} ({e[2]})")
        for i in sorted(set(cheapest.values())):
            if dsu.union(edges[i][0], edges[i][1]):
                chosen.append(i)
                if trace is not None: trace.append(f"    merge via {edges[i][0]}-{edges[i][1]}")
            elif trace is not None:
                trace.append(f"    skip {edges[i][0]}-{edges[i][1]} (already merged this round)")
    return chosen


def fmt(edges, ids):
    return sorted(f"{min(edges[i][0], edges[i][1])}{max(edges[i][0], edges[i][1])}({edges[i][2]})" for i in ids)


def cost(edges, ids): return sum(edges[i][2] for i in ids)


def all_msts(vertices, edges):
    """Brute-force reference: every spanning tree of minimum cost."""
    n = len(vertices); best, found = None, []
    for combo in itertools.combinations(range(len(edges)), n - 1):
        d = DSU(vertices)
        if all(d.union(edges[i][0], edges[i][1]) for i in combo):
            c = cost(edges, combo)
            if best is None or c < best: best, found = c, [combo]
            elif c == best: found.append(combo)
    return best, found


def run_all(title, edges, show_trace=True):
    print(f"\n################ {title} ################")
    print("Edges:", [f"{u}{v}={w}" for u, v, w in edges])
    out = {}
    for name, fn in (("Kruskal", lambda t: kruskal(V, edges, "first", t)),
                     ("Prim(start=A)", lambda t: prim(V, edges, "A", "first", t)),
                     ("Boruvka", lambda t: boruvka(V, edges, "first", t))):
        tr = []
        ids = fn(tr)
        print(f"\n--- {name} ---")
        if show_trace: print("\n".join(tr))
        print("MST edges:", fmt(edges, ids), "| total cost =", cost(edges, ids))
        out[name] = ids
    return out


if __name__ == "__main__":
    run_all("ORIGINAL GRAPH (all weights distinct => unique MST)", EDGES)
    best, found = all_msts(V, EDGES)
    print(f"\nBrute force over all C({len(EDGES)},{len(V)-1}) edge subsets: min cost = {best}, number of MSTs = {len(found)}")

    run_all("TIED GRAPH, deterministic tie-break = lowest edge id first", TIED, show_trace=False)
    print("\n######## TIED GRAPH: different (equally legal) tie-breaking / start vertices ########")
    seen = {}
    configs = [("Kruskal ties=first", lambda: kruskal(V, TIED, "first")),
               ("Kruskal ties=last", lambda: kruskal(V, TIED, "last")),
               ("Prim start=A ties=first", lambda: prim(V, TIED, "A", "first")),
               ("Prim start=A ties=last", lambda: prim(V, TIED, "A", "last")),
               ("Prim start=E ties=first", lambda: prim(V, TIED, "E", "first")),
               ("Prim start=D ties=last", lambda: prim(V, TIED, "D", "last")),
               ("Boruvka ties=first", lambda: boruvka(V, TIED, "first")),
               ("Boruvka ties=last", lambda: boruvka(V, TIED, "last"))]
    for name, fn in configs:
        ids = fn()
        print(f"{name:<26} cost={cost(TIED, ids)}  edges={fmt(TIED, ids)}")
        seen[tuple(sorted(ids))] = True
    best, found = all_msts(V, TIED)
    print(f"\nBrute force on tied graph: min cost = {best}, number of distinct MSTs = {len(found)}")
    for f in found: print("   ", fmt(TIED, f))
    print(f"Distinct edge sets actually produced by the 8 runs above: {len(seen)}  (all with cost {best})")
    print("\nBoruvka tie hazard: components X,Y,Z joined by a triangle of three equal edges XY, YZ, ZX.")
    print("If each component picked a DIFFERENT equal edge (X:XY, Y:YZ, Z:ZX) adding all three closes a cycle:")
    d = DSU("XYZ"); print("  union results:", [d.union(a, b) for a, b in ("XY", "YZ", "ZX")], "(False = cycle prevented only by the union-find check / consistent tie-break)")
