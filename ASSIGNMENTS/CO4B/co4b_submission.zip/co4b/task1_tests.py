"""Task 1.3 modified widths + 1.4 boundary / validation tests."""
import random
from task1_word_wrap import *

print("######## 1.3 MODIFIED WIDTHS (predictions in predictions_task1.txt) ########")
base_best, base_lines, _, _ = word_wrap(TEXT, 24)
for w in (18, 30, 40):
    best, lines = report(TEXT, w, show_dp=False)
    print(f"-> vs baseline: first differing line = "
          f"{next((k+1 for k,(x,y) in enumerate(zip(lines, base_lines)) if x!=y), 'none')}, "
          f"penalty {base_best} -> {best} ({'increase' if best>base_best else 'decrease' if best<base_best else 'same'})")

print("\n######## 1.4 BOUNDARY TESTS ########")
total_len = line_length(TEXT, 0, len(TEXT)-1)
print(f"Whole text needs exactly {total_len} characters on one line.")
for w in (total_len, total_len-1):
    report(TEXT, w, show_dp=False)

print("\n-- word longer than width must be rejected, not silently mangled --")
try:
    word_wrap(TEXT, 10)
except ValueError as e:
    print("ValueError raised as expected:", e)
print("\n-- empty text --", word_wrap([], 10)[:2])
print("-- single word --", word_wrap(["hello"], 5)[:2])
print("-- every word exactly W long --", word_wrap(["abcd"]*4, 4)[:2], "(each word alone, all penalties 0)")

print("\n-- case where DP beats first-fit greedy --")
w = "aaa bb cc ddddd".split()
print(w, "W=6  DP =", word_wrap(w, 6)[0], " greedy =", greedy_wrap_penalty(w, 6))

print("\n-- 500 random cross-checks DP vs exhaustive enumeration --")
random.seed(7)
bad = 0
for _ in range(500):
    n = random.randint(1, 9)
    words = ["x"*random.randint(1, 8) for _ in range(n)]
    W = random.randint(max(len(x) for x in words), 20)
    if word_wrap(words, W)[0] != brute_force_min(words, W):
        bad += 1
print("mismatches:", bad)
