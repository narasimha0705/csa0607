import copy, random, itertools
from task4_assembly import *

b = BASE
print_solution("BASELINE (reference)", **b)

# 4.3 ---- transfer time change
m = copy.deepcopy(b); m["t"][0][2] = 20
print("\n######## 4.3 transfer line1->line2 after station 3 raised 1 -> 20 ########")
t3, r3, _ = print_solution("4.3 MODIFIED", **m)

# 4.4 ---- production disruption
d = copy.deepcopy(b); d["a"][1][3] = 15
print("\n######## 4.4 line 2 station 4 slowed 4 -> 15 ########")
t4, r4, _ = print_solution("4.4 DISRUPTION", **d)

# ---- boundary tests / validation
print("\n######## BOUNDARY & VALIDATION TESTS ########")
print("n=1 station:", assembly_dp([[5], [3]], [[], []], [1, 2], [1, 1])[:2], "(expect line 2: 2+3+1 = 6 vs line 1: 1+5+1 = 7)")
print("All transfers huge (1000): route must never switch ->",
      assembly_dp(b["a"], [[1000]*5, [1000]*5], b["e"], b["x"])[:2])
print("Zero-cost transfers: total =", assembly_dp(b["a"], [[0]*5, [0]*5], b["e"], b["x"])[0],
      "(= e1/e2 + best station each stage + exit, sanity bound)")
try:
    assembly_dp([[1, 2], [3]], [[1], [1]], [0, 0], [0, 0])
except ValueError as ex:
    print("Invalid input rejected:", ex)

def brute(a, t, e, x):
    n = len(a[0]); best = None
    for route in itertools.product((0, 1), repeat=n):
        c = e[route[0]] + a[route[0]][0]
        for j in range(1, n):
            c += (t[route[j-1]][j-1] if route[j] != route[j-1] else 0) + a[route[j]][j]
        c += x[route[-1]]
        best = c if best is None else min(best, c)
    return best

random.seed(11); bad = 0
for _ in range(500):
    n = random.randint(1, 8)
    rnd = lambda k: [random.randint(0, 9) for _ in range(k)]
    a = [rnd(n), rnd(n)]; t = [rnd(n-1), rnd(n-1)]; e = rnd(2); x = rnd(2)
    if assembly_dp(a, t, e, x)[0] != brute(a, t, e, x): bad += 1
print("500 random instances DP vs exhaustive 2^n enumeration, mismatches:", bad)
