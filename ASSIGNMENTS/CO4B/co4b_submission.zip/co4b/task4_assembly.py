"""Task 4 - Two-line assembly-line scheduling (Dynamic Programming).
Conventions (0-based internally, printed 1-based):
  a[l][j]  processing time at station j on line l
  t[l][j]  transfer time to LEAVE line l after station j (to the other line, before station j+1), j = 0..n-2
  e[l]     entry time onto line l ,  x[l]  exit time from line l
  f[l][j]  fastest time to get THROUGH station j on line l
"""
import sys


def validate(a, t, e, x):
    n = len(a[0])
    if n < 1 or len(a[1]) != n:
        raise ValueError("both lines need the same, non-zero number of stations")
    if len(t[0]) != n - 1 or len(t[1]) != n - 1:
        raise ValueError("transfer lists need n-1 entries")
    if any(v < 0 for v in list(a[0]) + list(a[1]) + list(t[0]) + list(t[1]) + list(e) + list(x)):
        raise ValueError("times must be non-negative")


def assembly_dp(a, t, e, x):
    """Returns total, route (line index per station), f, choice, trace.
    trace[j] = dict with staying/transfer costs for each line and the selected predecessor."""
    validate(a, t, e, x)
    n = len(a[0])
    f = [[0] * n for _ in range(2)]
    came_from = [[None] * n for _ in range(2)]      # line we were on at station j-1
    trace = []
    for l in range(2):
        f[l][0] = e[l] + a[l][0]
    for j in range(1, n):
        row = {"station": j + 1}
        for l in range(2):
            other = 1 - l
            stay = f[l][j - 1] + a[l][j]
            switch = f[other][j - 1] + t[other][j - 1] + a[l][j]
            if stay <= switch:                      # tie -> prefer staying (fewer transfers)
                f[l][j], came_from[l][j], pick = stay, l, "stay"
            else:
                f[l][j], came_from[l][j], pick = switch, other, "transfer"
            row[l] = (stay, switch, pick)
        trace.append(row)
    finish = [f[l][n - 1] + x[l] for l in range(2)]
    last = 0 if finish[0] <= finish[1] else 1
    total = finish[last]
    route = [0] * n
    route[n - 1] = last
    for j in range(n - 1, 0, -1):
        route[j - 1] = came_from[route[j]][j]
    return total, route, f, trace, finish


def print_solution(title, a, t, e, x):
    total, route, f, trace, finish = assembly_dp(a, t, e, x)
    n = len(a[0])
    print(f"\n===== {title} =====")
    print(f"Line 1 times: {a[0]}   Line 2 times: {a[1]}")
    print(f"Transfer out of line 1 (after stn j): {t[0]}   out of line 2: {t[1]}   entry e={e}  exit x={x}")
    print(f"Initial: f1[1] = e1 + a1[1] = {f[0][0]},  f2[1] = e2 + a2[1] = {f[1][0]}")
    print("\nDP trace (cost to finish station at that line):")
    print(f"{'Stn':>3} | {'L1 stay':>7} {'L1 xfer':>7} {'pick':>8} {'f1':>4} | {'L2 stay':>7} {'L2 xfer':>7} {'pick':>8} {'f2':>4}")
    for row in trace:
        j = row["station"]
        s1, w1, p1 = row[0]; s2, w2, p2 = row[1]
        print(f"{j:>3} | {s1:>7} {w1:>7} {p1:>8} {f[0][j-1]:>4} | {s2:>7} {w2:>7} {p2:>8} {f[1][j-1]:>4}")
    print(f"Finish: f1[n]+x1 = {finish[0]}, f2[n]+x2 = {finish[1]}  -> exit via line {route[-1]+1}")
    print("\nOptimal route:")
    print("Entry")
    transfers = []
    for j in range(n):
        if j > 0 and route[j] != route[j - 1]:
            transfers.append((j, route[j - 1] + 1, route[j] + 1))
            print(f" | Transfer (line {route[j-1]+1} -> line {route[j]+1}, cost {t[route[j-1]][j-1]})")
        else:
            print(" |")
        print(f"Line {route[j]+1} - Station {j+1}  (time {a[route[j]][j]})")
    print(" |\nExit")
    print(f"Lines per station: {[r+1 for r in route]} | transfer points (after station): {[tr[0] for tr in transfers]}")
    print(f"Minimum Production Time = {total}")
    return total, route, transfers


BASE = dict(a=[[7, 9, 3, 4, 8, 4], [8, 5, 6, 4, 5, 7]],
            t=[[2, 3, 1, 3, 4], [2, 1, 2, 2, 1]],
            e=[2, 4], x=[3, 2])

if __name__ == "__main__":
    print_solution("BASELINE", **BASE)
