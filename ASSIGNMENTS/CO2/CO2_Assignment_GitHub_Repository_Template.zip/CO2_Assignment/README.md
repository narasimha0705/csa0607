# CSA06 – Design and Analysis of Algorithms
## Assignment 2 (CO2)

This repository contains the work for Questions Q1–Q7.

### Required contents
- Separate pseudocode for each question.
- Separate source-code implementation for each question.
- Execution screenshots for each implementation.
- Test datasets and raw experimental measurements.
- Complexity analysis and mathematical derivations.
- Comparison tables, graphs, observations and recommendations.
- Complete Q7 Day-4 Design Challenge analysis (Parts A–F).
- Final report in `Final_Report/CO2_Assignment_Report.docx`.

### Question folders
1. `Q1_Sorting_Algorithms`
2. `Q2_Sequential_Search`
3. `Q3_Brute_Force_String_Matching`
4. `Q4_Brute_Force_Closest_Pair`
5. `Q5_Brute_Force_Convex_Hull`
6. `Q6_Exhaustive_Search`
7. `Q7_Day4_Design_Challenge`

### Before submission
- Replace placeholder README files with your pseudocode, code, screenshots and evidence.
- Run every program and capture genuine execution screenshots.
- Include your own measured operation counts and experimental results.
- Ensure the report and repository contain matching results.
- Verify that all files are committed and pushed to your individual GitHub repository.

**Important:** This ZIP is a repository folder template. It does not contain completed algorithms, measured results, or execution screenshots.
