import csv
import time
import matplotlib.pyplot as plt

def linear_search(data, target):
    comparisons = 0
    for i, value in enumerate(data):
        comparisons += 1
        if value == target:
            return i, comparisons
    return -1, comparisons

def binary_search_iterative(data, target):
    low, high = 0, len(data) - 1
    comparisons = 0
    while low <= high:
        mid = low + (high - low) // 2
        comparisons += 1
        if data[mid] == target:
            return mid, comparisons
        comparisons += 1
        if data[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1, comparisons

def binary_search_recursive(data, target):
    comparisons = 0
    def search(low, high):
        nonlocal comparisons
        if low > high:
            return -1
        mid = low + (high - low) // 2
        comparisons += 1
        if data[mid] == target:
            return mid
        comparisons += 1
        if data[mid] < target:
            return search(mid + 1, high)
        return search(low, mid - 1)
    return search(0, len(data) - 1), comparisons

def timed_search(fn, data, target, repeats=30):
    total_comparisons = 0
    result = -1
    start = time.perf_counter()
    for _ in range(repeats):
        result, comparisons = fn(data, target)
        total_comparisons += comparisons
    elapsed_ms = (time.perf_counter() - start) * 1000 / repeats
    return result, total_comparisons // repeats, elapsed_ms

sizes = [1_000, 10_000, 100_000, 1_000_000]
rows = []
for n in sizes:
    sorted_data = list(range(100000, 100000 + n))
    unsorted_data = sorted_data[::-1]
    target = -1  # absent target: worst-case test for linear search
    tests = [
        ("Linear search (unsorted)", linear_search, unsorted_data),
        ("Iterative binary search (sorted)", binary_search_iterative, sorted_data),
        ("Recursive binary search (sorted)", binary_search_recursive, sorted_data),
    ]
    for name, fn, data in tests:
        index, comparisons, elapsed_ms = timed_search(fn, data, target)
        assert index == -1
        row = {
            "algorithm": name,
            "n": n,
            "target": target,
            "result_index": index,
            "comparisons": comparisons,
            "average_time_ms": round(elapsed_ms, 6)
        }
        rows.append(row)
        print(f"{name:36s} n={n:>7} comparisons={comparisons:>8} "
              f"average_time_ms={elapsed_ms:.6f} result={index}")

with open("benchmark_results.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

algorithms = list(dict.fromkeys(row["algorithm"] for row in rows))
plt.figure(figsize=(9, 5))
for algorithm in algorithms:
    subset = [row for row in rows if row["algorithm"] == algorithm]
    plt.plot([r["n"] for r in subset], [r["average_time_ms"] for r in subset],
             marker="o", label=algorithm)
plt.xscale("log")
plt.yscale("log")
plt.xlabel("Number of student records (n)")
plt.ylabel("Average search time (ms)")
plt.title("Student Registration Search: Experimental Performance")
plt.grid(True, which="both", linestyle="--", alpha=0.4)
plt.legend()
plt.tight_layout()
plt.savefig("search_performance.png", dpi=200)
print("\nSaved benchmark_results.csv and search_performance.png")
