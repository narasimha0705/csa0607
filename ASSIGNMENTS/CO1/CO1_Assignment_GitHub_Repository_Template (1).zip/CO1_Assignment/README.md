# CO1 Assignment — Student Record Search Analysis

**Course:** CSA06 — Design and Analysis of Algorithms  
**Assignment:** CO1 — Design, Analyse and Validate an Efficient Search Strategy for a Large-Scale Student Record System

## Problem
Compare algorithms for searching student registration numbers in datasets of 1,000, 10,000, 100,000 and 1,000,000 records. Analyse mathematical and asymptotic complexity and recommend a strategy for 50,000 searches per hour with daily record updates.

## Algorithms implemented
1. **Iterative Linear Search** — works on unsorted data; worst-case time `O(n)`.
2. **Iterative Binary Search** — requires sorted data; worst-case time `O(log n)`.
3. **Recursive Binary Search** — requires sorted data; worst-case time `O(log n)` and `O(log n)` recursion stack space.

## Requirements
- Python 3
- Matplotlib

Install dependency:
```bash
python -m pip install matplotlib
```

## Run the benchmark
From the repository root:
```bash
python Task_8_Implementation_Testing/Source_Code/search_benchmark.py
```

The program prints comparisons and average elapsed time, then creates:
- `benchmark_results.csv`
- `search_performance.png`

The two output files are written to the current working directory. For tidy submission, run the script from `Task_9_Experimental_Performance/` or move the generated files into that folder and `Report/Tables_and_Graphs/` respectively.

## Important experimental notes
- The benchmark uses a missing target to test the worst case for linear search.
- Binary search is run on sorted data; linear search is run on a reversed (unsorted) list containing the same keys.
- Timings depend on the machine and system load. Do not report sample or guessed timings as actual measurements.
- Add screenshots of your own terminal output to `Report/Output_Screenshots/`.
- Include source-code screenshots in `Report/Source_Code_Screenshots/` if your instructor requires them.
- For a complete evaluation, test present targets at the first, middle and last positions, plus absent targets and empty/single-item arrays.
- The benchmark measures search time only. If the initial data is unsorted, discuss sorting/index construction separately.

## Recommended repository structure
```text
CO1_Assignment/
├── Task_1_Algorithm_Design/
├── Task_2_Basic_Operation/
├── Task_3_Mathematical_Complexity/
├── Task_4_Case_Analysis/
├── Task_5_Asymptotic_Analysis/
├── Task_6_Recurrence_Formulation/
├── Task_7_Recurrence_Solution/
├── Task_8_Implementation_Testing/
│   └── Source_Code/
│       └── search_benchmark.py
├── Task_9_Experimental_Performance/
├── Task_10_Theory_vs_Experiment/
├── Task_11_Final_Recommendation/
├── Task_12_Design_Challenge/
└── Report/
    ├── Source_Code_Screenshots/
    ├── Output_Screenshots/
    ├── Analysis/
    ├── Tables_and_Graphs/
    └── Documentation/
        └── CO1_Assignment_Student_Record_Search_Analysis.docx
```

## Day-4 Design Challenge — short recommendation
At 1,000,000 records, binary search takes about 20 midpoint levels per query, while linear search can inspect one million records in the worst case. 50,000 requests/hour is approximately 13.9 requests/second on average. Since records are added only daily, a persistent database index (such as a B-tree/B+ tree index) is a strong production recommendation. Use the benchmark results and a load test to validate real performance.

## Submission checklist
- [ ] Run the program on your own computer.
- [ ] Verify the outputs and save actual screenshots.
- [ ] Include the generated CSV and graph.
- [ ] Replace experimental placeholders in the report with your measured results.
- [ ] Review the report against all 12 assignment tasks.
